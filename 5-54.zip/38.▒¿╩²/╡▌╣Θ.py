# -*- coding: utf-8 -*-
"""
Created on Sat Sep 14 17:54:09 2019

@author: zhazhi
"""

class Solution:
    def countAndSay(self, n: int) -> str:
        if  n==1 or n==0:
            return "1"
        
        count =0
        res=""     
        temp="1"
        for char in (self.countAndSay(n-1)):
            if char == temp:
                count +=1     
            else:
                if count >0:
                    res += str(count) + temp
                count =1
                temp=char
        res += str(count) + char
        return res

ss=Solution()
n=7
s=ss.countAndSay(n)
print(s)
