# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 16:21:54 2019

@author: zhazhi
"""

class Solution:
    def countAndSay(self, n: int) -> str:
        init="1"
        res=""
        if n==1 or n==0:
            return init
        else:
            if n>=2:
                init =init +"1"
                res=init
            for i in range (3,n+1):
                res=self.compute(i,init)
                init = res
        return res

    def compute(self,i,init):
        length = len(init) 
        index=0
        count =1
        res=""     
        while (index < length):
            target = init[index]
            index+=1
            if index <length and target == init[index]  :
                count +=1
            else:
                res += str(count) + target
                count=1
        return res
    
    
    
ss=Solution()
n=8
s=ss.countAndSay(n)
print(s)
