# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 22:26:26 2019

@author: ACER
"""

class Solution(object):
    def permute(self, nums):
        if len(nums)==0:
            return [[]]
        if len(nums)==1:
            return [nums]
        dp=[]
        dp1=[]
        dp_value=[]
        for i in range (1,len(nums)):
            if i ==1:
                dp.append([nums[i-1],nums[i]])
                dp.append([nums[i],nums[i-1]])
                for j in dp:
                    dp_value.append(j)
            else:
                dp_value=[]
                for value in dp:
                    count = 0
                    dp1=[100] * (2 *len(value)+1)
                    while (count < len(dp1)):
                        dp1=[100] * (2 *len(value)+1)
                        for j in range (len(value)):
                            dp1[2*j+1]=value[j]
                        dp1[count]=nums[i]
                        dp_value.append(dp1)
                        count +=2
                count =dp_value[0].count(100)
                for j in dp_value:
                    for i in range(count):
                        j.remove(100)
                dp = dp_value    
     #   print(dp_value)
        
import time 
now = time.time()     
ss=Solution()

nums=[1,1,2,3,4,5,6,7]
s=ss.permute(nums)
#print(s)
end = time.time()
#print(s)
print(end - now)