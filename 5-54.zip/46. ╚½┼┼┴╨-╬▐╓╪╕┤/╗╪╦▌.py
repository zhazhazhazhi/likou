# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 16:45:14 2019

@author: ACER
"""

class Solution(object):
    def permute(self, nums):
        dp=[]
        n=len(nums)

        self.solve(n,nums,dp,first=0)
        return (dp)
        
    def solve(self,n,nums,dp,first):
        if first == n:
            dp.append(nums[:])
        for i in range (first,n):  
            nums[first],nums[i] = nums[i],nums[first]
            self.solve(n,nums,dp,first+1)
            nums[first],nums[i] = nums[i],nums[first]
        
    
ss=Solution()

nums=[2,3,4]
s=ss.permute(nums)

print(s)