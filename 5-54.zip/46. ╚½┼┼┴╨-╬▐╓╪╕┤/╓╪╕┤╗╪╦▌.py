# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 21:12:30 2019

@author: ACER
"""

class Solution(object):
    def permute(self, nums):
        dp=[]
        res=[]
        self.solve(nums,dp,res)
        return (res)
        
    def solve(self,nums,dp,res):
        if not nums:
            res.append(dp)
            
        for i in range (len(nums)): 
            self.solve(nums[:i]+nums[i+1:],dp+[nums[i]],res)

        
    
ss=Solution()

nums=[2,3,4]
s=ss.permute(nums)

print(s)