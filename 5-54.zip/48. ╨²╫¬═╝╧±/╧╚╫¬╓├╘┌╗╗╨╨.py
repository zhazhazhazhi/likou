# -*- coding: utf-8 -*-
"""
Created on Mon Oct  7 21:38:05 2019

@author: ACER
"""

class Solution(object):
    def rotate(self, matrix):
        if len(matrix)==0 or len(matrix[0])==0:
            return matrix
        # 转置
        for i in range (len(matrix)):
            for j in range (i,len(matrix)):
                if i==j:
                    continue
                else:
                    temp = matrix[j][i]
                    matrix[j][i] = matrix[i][j]
                    matrix[i][j] = temp
        # 换行
        length = int(len(matrix)/2)
        for j in range(length):
            for i in range (len(matrix)):
                temp=matrix[i][len(matrix)-1-j]
                matrix[i][len(matrix)-1-j] = matrix[i][j] 
                matrix[i][j] =temp
        for i in (matrix):
            print(i)
        
                
ss=Solution()

#matrix = [  [1,2,3],  [4,5,6],  [7,8,9]]
#matrix =[  [ 5, 1, 9,11],  [ 2, 4, 8,10],  [13, 3, 6, 7],  [15,14,12,16]]
matrix=[[]]
s=ss.rotate(matrix)
#print(len(matrix[0]))

print(s)
 