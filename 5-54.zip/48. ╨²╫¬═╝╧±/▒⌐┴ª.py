# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 21:13:37 2019

@author: ACER
"""

class Solution(object):
    def rotate(self, matrix):
        if len(matrix)==0 or len(matrix[0])==0:
            return matrix
        one=[]
        for i in range(len(matrix)):
            for j in range(len(matrix)):
                one.append(matrix[i][j])
        n = len(one)
        
        for i in range(len(matrix)):
            start = n- len(matrix) +i 
            for j in range(len(matrix)):
                matrix[i][j] =  one[ start-len(matrix)*j ]
        print(matrix)
                
ss=Solution()

#matrix = [  [1,2,3],  [4,5,6],  [7,8,9]]
matrix =[  [ 5, 1, 9,11],  [ 2, 4, 8,10],  [13, 3, 6, 7],  [15,14,12,16]]
#matrix=[[]]
s=ss.rotate(matrix)
#print(len(matrix[0]))
print(s)
 