# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 21:29:19 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None

def creatlist(nums):
    last=None
    for num in reversed(nums):
        node=ListNode(num)
        node.next=last
        last=node
    return last
class Solution:
    def reverseKGroup(self, head: ListNode, k: int) -> ListNode:
        if head==None:
            return None

        length=head
        all_length=0
        while (length):
            all_length+=1
            length=length.next
            
        if all_length<k:
            return head
        
        return head
        re=ListNode(0)
        r=re
        lst=[]
        while (1):

            for i in range(k):
                lst.append(ListNode(head.val))
                head=head.next
                all_length-=1
                
            for i in range(k-1,-1,-1):
                r.next=lst[i]
                r=r.next
            lst=[]
            if all_length<k:
                r.next=head
                break
        self.print_list(re.next)
    
    def print_list(self,node):
        while(node):
            print(node.val,' ',end='')
            node=node.next
            
if __name__ == "__main__":
    l11=[]
    k=2
    l1=creatlist(l11)
    
    s=Solution()
    s.reverseKGroup(l1,k)
    