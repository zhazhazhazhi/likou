# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 22:51:47 2019

@author: zhazhi
"""
class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None

def creatlist(nums):
    last=None
    for num in reversed(nums):
        node=ListNode(num)
        node.next=last
        last=node
    return last
class Solution:
    def reverseKGroup(self, head: ListNode, k: int) -> ListNode:
        if head==None:
            return None
        
        length=head
        all_length=0
        while (length):
            all_length+=1
            length=length.next        
        re=ListNode(0)
        r=re
        lst=[]
        count=0
        
        while (1):
            start=head
            head=head.next
            start.next=None
            lst.append(start)
            all_length-=1
            count+=1
            if count==k:
                for i in range(k-1,-1,-1):
                    r.next=lst[i]
                    r=r.next
                lst=[]
                count=0
            if all_length <k:
                r.next=head
                break
            


                
            
        self.print_list(re.next)
    def print_list(self,node):
        while(node):
            print(node.val,' ',end='')
            node=node.next
            
if __name__ == "__main__":
    l11=[1,2,3,4,5]
    k=2
    l1=creatlist(l11)
    
    s=Solution()
    s.reverseKGroup(l1,k)
    