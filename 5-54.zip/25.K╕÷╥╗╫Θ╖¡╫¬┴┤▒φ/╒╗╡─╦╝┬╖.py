# -*- coding: utf-8 -*-
"""
Created on Sat Aug 10 14:12:14 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None
    
def creatlist(nums):
    last=None
    for num in reversed( nums):
        node=ListNode(num)
        node.next=last
        last=node
    return last

class Solution:
    def reverseKGroup(self, head: ListNode, k: int) -> ListNode:
        lst=[]
        re=ListNode(0)
        r=re
        count=0
        #for i in range(2):
        
        while (head):
            start=head
            head=head.next
            start.next=None
            lst.append(start)   
            count+=1
            
            if count==k:
                while (lst):
                    r.next=lst.pop()
                    r=r.next
                count=0
                
        if lst:
            for i in range(len(lst)):
                r.next=lst[i]
        
            
        self.printlist(re)
    def printlist(self,node):
        while (node):
            print(node.val,' ',end='' )
            node=node.next
if __name__=="__main__":
    l11=[1,2,3,4,5]
    k=2
    l1=creatlist(l11)
    s=Solution()
    a=s.reverseKGroup(l1,k)
    