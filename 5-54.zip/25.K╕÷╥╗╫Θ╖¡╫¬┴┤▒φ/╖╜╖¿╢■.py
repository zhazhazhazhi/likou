# -*- coding: utf-8 -*-
"""
Created on Sat Aug 10 14:12:14 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None
    
def creatlist(nums):
    last=None
    for num in reversed( nums):
        node=ListNode(num)
        node.next=last
        last=node
    return last

class Solution:
    def reverseKGroup(self, head: ListNode, k: int) -> ListNode:
        length=head
        all_length=0

        while (length):
            all_length+=1
            length=length.next
        
        re=ListNode(0)
        r=re
        while (head):
            pre=r
            first=head
            for i in range(k):
                start= head
                last_start=start
                head=head.next
                if r is pre :
                    last_start.next=None
                else:
                    last_start.next=pre
                pre=last_start
            all_length-=k
            r.next=last_start
            r=first
            if all_length < k:
                r.next=head
                break
        self.printlist(re.next)
        
    def printlist(self,node):
        while (node):
            print(node.val,' ',end='' )
            node=node.next
if __name__=="__main__":
    l11=[1,2,3,4,5]
    k=2
    l1=creatlist(l11)
    s=Solution()
    a=s.reverseKGroup(l1,k)
    