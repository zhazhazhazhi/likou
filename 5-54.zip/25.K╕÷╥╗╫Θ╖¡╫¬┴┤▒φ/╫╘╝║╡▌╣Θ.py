# -*- coding: utf-8 -*-
"""
Created on Sat Aug 10 22:42:30 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None
    
def creatlist(nums):
    last=None
    for num in reversed( nums):
        node=ListNode(num)
        node.next=last
        last=node
    return last


class Solution:
    def reverseKGroup(self, head: ListNode, k: int) -> ListNode:
        
        cur = head
        count = 0
        while cur and count!= k:
            cur = cur.next
            count += 1
        if count == k:
            cur=self.reverseKGroup(cur,k)
            while count:
                
                mid=head.next
                head.next=cur

                cur=head
                head=mid

                count-=1
            self.printlist(head)
            head=   cur
        return head

        
    def printlist(self,node):
        while (node):
            print(node.val,'  ',end='' )

            node=node.next
        print( )
        
if __name__=="__main__":
    l11=[1,2,3,4,5]
    k=3
    l1=creatlist(l11)
    s=Solution()
    a=s.reverseKGroup(l1,k)
    print(s.printlist(a))
    