# -*- coding: utf-8 -*-
"""
Created on Sun Jul 14 22:27:29 2019

@author: zhazhi
"""
import re
#s = "aa"
#p = "a"

#s = "aa"
#p = "a*"
#s = "aa"
#p = ".*"

#s = "aab"
#p = "c*a*b"
#s = "mississippi"
#p = "mis*is*p*."

#s="ab"
#p=".*c"
#s=''
#p='.'
"""
s ="aaa"
p="ab*ac*a"

result=re.findall(p,s)

print(result ,'   ' ,len(result))
result=set(result)

if s in result:
    print(True)
else:
    print(False)


"""
s="aabb"
p=".*"
dp = [[False for j in range(len(s)+1)] for i in range(len(p)+1)]

dp[0][0]=True
for i in range(1,len(p)):
    if p[i]=="*" and p[i-1]!="*":
        dp[i+1][0] = dp[i-1][0]


for i in range(len(p)):
    for j in range(len(s)):
        if p[i]==s[j] or p[i]==".":
            dp[i+1][j+1] = dp[i][j]
        else:
            if i>0 and p[i]=="*":
                if p[i-1]!=s[j]:
                    
                    dp[i+1][j+1] = dp[i-1][j+1]
                if p[i-1]==s[j] or p[i-1]==".":
                    dp[i+1][j+1] = dp[i-1][j+1] or dp[i][j] or dp[i+1][j]
print( dp[-1][-1])

