# -*- coding: utf-8 -*-
"""
Created on Mon Jul 15 19:24:40 2019

@author: zhazhi
"""

#s = "aab"
#p = "c*a*b"
#s = "aaa"
#p="ab*a*c*a"
s = "aasdfasdfasdfasdfas"
p="aasdf.*asdf.*asdf.*asdf.*s"
#s = ""
#p = "abc"
s="abcd"
p=".b*"
dp=[ [False for i in range (len(s) +1)   ] for i in range( len(p) +1)  ] 

dp[0][0]=True

for i in range(1,len(p)):
    if p[i]=="*" and p[i-1]!="*":
        dp[i+1][0] = dp[i-1][0]


for i in range ( len(p)):
    for j in range(len(s)):
        if p[i]==s[j] or p[i]=='.':
            dp[i+1][j+1]=dp[i][j]
        else:
            if i>0 and p[i]=='*':
                if p[i-1] =='.':
                    dp[i+1][j+1]=dp[i][j] or  dp[i+1][j]  or dp[i-1][j+1] 
                if (p[i-1] != s[j]) and (p[i-1] !='.'):
                    dp[i+1][j+1]= dp[i-1][j+1] 
                if (p[i-1] == s[j]) and (p[i-1] !='.'):
                    dp[i+1][j+1]= dp[i][j] or dp[i-1][j+1]    or  dp[i+1][j]             
print(dp[-1][-1])







