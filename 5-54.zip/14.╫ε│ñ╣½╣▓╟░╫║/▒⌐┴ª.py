#x=['abc']
x=["aca","cba"]

#x=["flower","flow","flight"]
if len(x)==0:
    print ('iiii')
else:
    res=''
    flag=False
    for i in range(len (min(x,key=len) )):
        count =0
        for j in range(len(x)):
            if x[0][i]  ==x[j][i]:
                count +=1
                if j== len(x):
                    res += x[j][i]
                   # count =0
            else:
                flag=True
                break
        if flag:
            break
    print(res)