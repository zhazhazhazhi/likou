# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 19:18:09 2019

@author: zhazhi
"""

class Solution(object):
    def combinationSum2(self, candidates, target):
        candidates.sort()
        start=0
        end=len(candidates)  
        path=[]
        res=[]
        a=self.compute(candidates,target,start,end,path,res)
        print(a)
    
    def compute(self,candidates,target,start,end,path,res):
        if target == 0:
            if path not in res:
                res.append(path[:])
        
        for i in range (start,end):
            temp= target - candidates[i]
            if temp <0:
                break
            path.append(candidates[i])
            self.compute(candidates,temp,i+1,end,path,res)
            path.pop()
            
        return res

ss=Solution()
candidates =[2,5,2,1,2]
target=5
s=ss.combinationSum2(candidates,target)
