# -*- coding: utf-8 -*-
"""
Created on Sat Jul  6 22:44:01 2019

@author: zhazhi
"""
s="-2147483649"
s=s.lstrip()
length=len(s)
x=[]
flag=False
if length==0 :
    print(0) 
else:
    if s[0] == '-'or s[0] =='+' or (s[0]>='0'and s[0]<='9'):
        x.append(s[0])
        if (s[0]>='0'and s[0]<='9'):
            flag=True
        for i in range(1,length):
            if  s[i]>='0'and s[i]<='9':
                x.append(s[i])
                flag=True
            else:
                break   
        if flag:
            length=len(x)
            s=int(''.join(x) )
            length=2**31
            if s<(-1*length):
                print(-1*length) 
            elif s>=(length):
                print(length-1)
            else:
                print(s)
        else:
            print(0)
    else:
        print(0)
        
        
        
    