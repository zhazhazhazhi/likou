# -*- coding: utf-8 -*-
"""
Created on Sun Jul  7 21:14:24 2019

@author: zhazhi
"""
#  52毫秒  
s="-+1"
s=s.lstrip()
length=len(s)
if length==0 :
    print(0) 
else:
    if s[0] == '-'or s[0] =='+' or (s[0]>='0'and s[0]<='9'):
        x=[]
        x.append(s[0])
        for i in range(1,length):
            if s[i]>='0'and s[i]<='9':
                x.append(s[i])
            else:
                break
        if (''.join(x[1:]) ).isdigit():
            s=int(''.join(x) )
            length=2**31
            if s<(-1*length):
                print(-1*length)
            elif s>=(1*length):
                print(2**31 -1)
            else:
                print(s)
        elif  (''.join(x)).isdigit():
            s=int(''.join(x) )
            print(s)
        else:
            print(0)
    else:
        print(0)
       
        
        
        
        
        
        
        