# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 14:55:08 2019

@author: zhazhi
"""

class Solution:
    def multiply(self, num1: str, num2: str) -> str:
        num2=num2[::-1]
        num1=num1[::-1]
        count,count1=0,0
        value=[]
        for i in num2:
            count1=0
            for j in num1:
                res=str(int(i)*int(j))
                res=res+'0'*(count+count1)
                count1 +=1
                value.append(res)
            count +=1
        res=0
        for i in value:
            res+=int(i)
        res=str(res)
        print(res)
            
        
ss=Solution()
num1 = "0"
num2 = "0"
s=ss.multiply(num1,num2)