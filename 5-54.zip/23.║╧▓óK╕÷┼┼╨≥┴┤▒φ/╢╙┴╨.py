# -*- coding: utf-8 -*-
"""
Created on Tue Aug  6 20:39:50 2019

@author: zhazhi
"""

from queue import PriorityQueue

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None

def creatlist(nums):
    lst=[]
    last=None
    for l in nums:
        for num in l:
            node=ListNode(num)
            node.next=last
            last=node
        lst.append(last)
    return lst

class Solution(object):
    def mergeKLists(self, lists):
        head = point = ListNode(0)
        q = PriorityQueue()
        for l in lists:
            if l:
                q.put((l.val, l))
        while not q.empty():
            val, node = q.get()
            return node
            point.next = ListNode(val)
            point = point.next
            node = node.next
            if node:
                q.put((node.val, node))
        #return head.next
        self.print_list(head.next)
      #  return head.next
                

    def print_list(self,node):
        while(node):
            print(node.val,' ',end='')
            node=node.next



if __name__ == "__main__":
   #l11=[[],[-1,5,11],[],[6,10]]
    l11=[[1,4,5],[1,3,4],[2,6]]
    l1=creatlist(l11)
    s=Solution()
    a=s.mergeKLists(l1)
    s.print_list(a)