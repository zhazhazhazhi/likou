# -*- coding: utf-8 -*-
"""
Created on Sun Sep  1 23:27:37 2019

@author: zhazhi
"""
#  In ascending order
class Solution(object):
    def searchRange(self, nums, target):
        if not nums:
            return [-1,-1]
        index=self.compute(nums,target)
        print(index)
        
    def compute(self,nums,target):
        left,right=0,len(nums)-1
        while (left<=right):
            
            if nums[left]== target and nums[right]==target:
                return [left,right]
            else:
                if nums[left] !=target:
                    left+=1
                if nums[right] != target:
                    right-=1
        left,right=-1,-1
        return [left,right]
        
        
                
            

    
ss=Solution()
nums=[5,7,7,7,7,7,7,7,8,8,10]
#nums=[5,7,7,8,8,10]

target=10
s=ss.searchRange(nums,target)