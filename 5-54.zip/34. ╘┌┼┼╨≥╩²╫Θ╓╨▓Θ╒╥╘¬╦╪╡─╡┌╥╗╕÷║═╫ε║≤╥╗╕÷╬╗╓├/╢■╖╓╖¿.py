# -*- coding: utf-8 -*-
"""
Created on Mon Sep  2 22:00:17 2019

@author: zhazhi
"""

class Solution(object):
    def searchRange(self, nums, target):
        
        left_index=self.compute_left(nums,target)
       # print (left_index)
        if nums[left_index] != target:
            return [-1,-1]
        # 右区间
        right_index=len(nums)-1-self.compute_right(nums,target)
        return [left_index,right_index]
    
    def compute_left(self,nums,target,):
        left,right=0,len(nums)-1
        while (left<right):       
            mid=(left+right)//2
            if nums[mid] >= target :
                right=mid 
            else:
                left =mid+1
          #  print (left,mid,right)
            
        return left
    
    def compute_right(self,nums,target):
        nums=sorted(nums,reverse=True)
        left,right=0,len(nums)-1
        while (left  <right):
            mid=(left+right)//2
            if nums[mid] <= target  :
                right=mid  
            else:
                left =mid +1

        return left

ss=Solution()
nums=[5,7,7,7,7,7,7,8,8,10]
#nums=[2,2]

target=10

s=ss.searchRange(nums,target)
print(s)