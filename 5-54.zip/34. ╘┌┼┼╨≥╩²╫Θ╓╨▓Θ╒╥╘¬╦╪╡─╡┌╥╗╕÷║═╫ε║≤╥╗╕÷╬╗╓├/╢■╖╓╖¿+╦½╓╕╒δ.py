# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 23:12:17 2019

@author: zhazhi
"""
class Solution(object):
    def searchRange(self, nums, target):
        if not nums:
            return [-1,-1]
        index=self.compute(nums,target)
        if nums[index[0]] !=target or nums[index[1]] !=target :
            return [-1,-1]
        return index

    def compute(self,nums,target):
        left,right=0,len(nums)-1
   #     while (left<right) and (nums[left]!=target or  nums[right]!=target) :
        while (left<right) and (nums[left]!= nums[right]) :
            mid= (left + right ) //2
            if nums[mid] >target:
                right =mid -1
            elif nums[mid] <target:
                left = mid +1
            else:
                if nums[left]<target:
                    left=left+1
                if nums[right ] > target :
                    right =right -1
        return [left,right]
    
        
ss=Solution()
nums=[5,7,7,7,7,7,7,7,8,8,10]
#nums=[5,7,7,8,8,10]

target=10
s=ss.searchRange(nums,target)
print(s)