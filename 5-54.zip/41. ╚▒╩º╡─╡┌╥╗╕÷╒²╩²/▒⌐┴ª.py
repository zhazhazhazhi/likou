# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 11:12:33 2019

@author: zhazhi
"""

class Solution(object):
    def firstMissingPositive(self, nums):
        min_value=50
        for i in range (len(nums)):
            if nums[i]>0:
                if min_value > nums[i]:
                    min_value= nums[i]
        if min_value ==1:
            while (1):
                min_value +=1
                if min_value in nums:
                    continue
                else:
                    return min_value
        else:
            return 1
ss=Solution()
nums=[0,1,2]
s=ss.firstMissingPositive(nums) 
print(s)