# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 14:37:08 2019

@author: zhazhi
"""
#当数据多，建立的字典数据多。


class Solution(object):
    def combinationSum(self, candidates, target):
        candidates.sort()
        dic={}
        length = len(candidates) -1
   #     for i in candidates:
  #          dic[i] =[]
#        dic[target]=[]
        
      #  dict = {}
     #   for i in range(1,target+1):
    #        dict[i]=[]
        
        
        for j in dic:  # jianshu
            for k in range (length):
                i=candidates[k]  # beijianshu
                if j >=i:
                #    print(i,j)
                    temp = j -i
                    if temp ==0:
                        dic[j].append([i])
                    else:
                        if temp in candidates:
                            for l in dic[temp]:
                                n=l[:]
                                n.append(i)
                                n.sort()
                                if n not in dic[j]:
                                    dic[j].append(n)

           
            
        print(dic[target])
ss=Solution()
candidates=[4,5,2]
candidates=[3,2,6,7]
[7,3,2]
candidates =[5,10,8,4,3,12,9]
candidates=[5,10,8,4,3,12,9]
candidates=[5,10,8,4,3,12,9]

candidates=[2,3,6,7]
#candidates=[1,2,3,4]
target=7


s=ss.combinationSum(candidates,target)
