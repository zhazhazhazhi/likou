# -*- coding: utf-8 -*-
"""
Created on Mon Sep 16 22:47:59 2019

@author: zhazhi
"""

class Solution(object):
    def combinationSum(self, candidates, target):
        candidates.sort()
        end = len(candidates) 
        start = 0
        path=[]
        res=[]
        a=self.compute(candidates,target,start,end,path,res)
        return a
        
    
    def compute(self,candidates,target,start,end,path,res):
        if target ==0:
            res.append(path[:])
        for i in range (start,end):
            temp= target - candidates[i]
            if temp<0:
                break
            path.append(candidates[i])
            self.compute(candidates,temp,i,end,path,res)
            path.pop()
        return res
            
            
            
ss=Solution()
candidates=[4,5,2]
candidates=[3,2,6,7]
[7,3,2]
candidates =[5,10,8,4,3,12,9]
candidates=[5,10,8,4,3,12,9]
candidates=[5,10,8,4,3,12,9]



target=27


s=ss.combinationSum(candidates,target)
print(s)