# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 12:15:39 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.data=x
        self.next=None

def create_list(nums):
    last = None
    for num in reversed(nums):
        list_node = ListNode(num)
        list_node.next = last
        last = list_node
    return last


class Solution:
    def removeNthFromEnd(self, head: ListNode, n: int) -> ListNode:
        re=ListNode(0)
        re.next=head
        start=re
        end=re
        i=0
        while(end.next):
            if i<n:
                i+=1
                end=end.next
            else:
                start=start.next
                end=end.next
        start.next=start.next.next
        return re.next
    
    def print_note(self,node):
        while(node):
            print ( ' value: ', node.data,end='')
            node = node.next            
        

if __name__ == "__main__":
    nums=[1,2,3,4,5]
    n=1
    l1 = create_list(nums)
    s = Solution()
    a=s.removeNthFromEnd(l1, n)
    print(s.print_note(a))