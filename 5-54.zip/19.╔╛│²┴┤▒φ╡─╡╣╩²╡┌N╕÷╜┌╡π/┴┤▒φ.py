# -*- coding: utf-8 -*-
"""
Created on Wed Jul 31 12:06:10 2019

@author: zhazhi
"""
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 14:17:00 2019

@author: zhazhi
"""
# 定义一个链表节点
class ListNode(object):
    def __init__(self, x):
        self.val = x
        self.next = None

# 这里为大家补充了创建链表的函数
def create_list(nums):
    last = None
    for num in reversed(nums):
        list_node = ListNode(num)
        list_node.next = last
        last = list_node
    return last

# 解决方案
class Solution:
    def removeNthFromEnd(self, head: ListNode, n: int) -> ListNode:
        print(ListNode)
        length=head
        count=0
        while(length):
            count+=1
            length=length.next
        
        if length ==1 and n==0:
            return head
        n=count-n
        if n==0:
            head=head.next
            count=count-1
            
        re=ListNode(head.val)
        r=re
        for i in range(count-1):
            
            if i==n-1:
                head=head.next
            else:
                head=head.next
                r.next=ListNode(head.val)
                r=r.next
        return re

    def printNode(self,node):
        while node:
            print ( ' value: ', node.val,end='')
            node = node.next

if __name__ == "__main__":
    nums=[1,2,3,4,5]
    n=2
    l1 = create_list(nums)
    print(l1)
    s = Solution()
  #  a=s.removeNthFromEnd(l1, n)
#    print(s.printNode(a))

                
                
        
