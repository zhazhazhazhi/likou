# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 20:52:55 2019

@author: ACER
"""

class Solution(object):
    def permute(self, nums):
        dp=[]
        nums.sort()
        res=[]
        self.solve(nums,dp,res)
        return (res)
        
    def solve(self,nums,dp,res):
        if not nums:
            res.append(dp)
        for i in range (len(nums)):  
            if i > 0 and nums[i] ==nums[i-1]:
                continue
            
            self.solve(nums[:i]+nums[i+1:],dp+[nums[i]],res)
        
    
ss=Solution()

nums=[1,1,2,4]
s=ss.permute(nums)

print(s)
print(len(s))