# -*- coding: utf-8 -*-
"""
Created on Sat Aug 17 16:17:46 2019

@author: zhazhi
"""
#872
class Solution(object):
    def findSubstring(self, s, words):
        if not s or not words:
            return None
        words_length=self.Series(words)
        dic={}
        for i in words:
            if i not in dic:
                dic[i]=1
            else:
                dic[i]+=1
        value=[]
        i=0
        while ( i<=len(s) - words_length ):
            
            dic_reference={}
            count=0 
            
            for key in words:
                length =len(key)
                res=s[i+count:i+length+count]
                if res not in dic:
                    break
                if res not in dic_reference:
                    dic_reference[res]=1
                else:
                    dic_reference[res] +=1
                count=count+length
            if dic_reference==dic:
                if i not in value:
                    value.append(i)
            i+=1
        print(value)

    def Series(self,words):
        res=''
        for i in range(len(words)):
            res=res+words[i]
        return len(res)
    
#s = "wordgoodgoodgoodbestword"
#s = "barfoothefoobarman"
#words = ["foo","bar","the"]

s = "aabbaabbaabb"
words = ["bb","aa","bb","aa","bb"]


#words = ["word","good","best","word"]

so=Solution()
a=so.findSubstring(s,words)
print(a)