# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 16:49:59 2019

@author: zhazhi
"""

#460
class Solution(object):
    def findSubstring(self, s, words):
        lst=[]
        dic={}
        for i in words:
            if i not in dic:
                dic[i]=0
            else:
                dic[i]+=1
        i=0
        every_length= len (words[0] )
        all_length =len(words) * every_length
        while ( i + all_length <= len(s) ):
            lst.append(s[i:i+all_length])
            i+=1

        value=[]
       # print(lst)
        for  i in range (len(lst)):
            flag=True
            count=0
            dic_reference={}
            for _ in range (len(words)):
                res=lst[i][count :count+every_length ]
                if res not in dic:
                    flag=False
                    break
                if res not in dic_reference:
                    dic_reference[res] =0
                else:
                    dic_reference[res] +=1
                
                if dic_reference[res] > dic[res] :
                    flag=False
                    break
                count+=every_length
            if flag:
               # print(lst[i])
                if dic_reference==dic:
                    value.append(i)
        print(value)
            
import time
now=time.time()
#s = "wordgoodgoodgoodbestword"
s = "barfoothefoobarman"
words = ["foo","bar"]
s="barfoofoobarthefoobarman"

words=["bar","foo","the"]

s ="abbaccaaabcabbbccbabbccabbacabcacbbaabbbbbaaabaccaacbccabcbababbbabccabacbbcabbaacaccccbaabcabaabaaaabcaabcacabaa"

words =["cac","aaa","aba","aab","abc"]
#words = ["word","good","best","word"]
#s = "barfoothefoobarman"
#words = ["foo","bar"]
so=Solution()
a=so.findSubstring(s,words)
end=time.time()
print(end-now)