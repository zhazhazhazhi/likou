# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 20:59:26 2019

@author: zhazhi
"""
class Solution(object):
    def findSubstring(self, s, words):
        lst=[]
        dic={}
        for i in words:
            if i not in dic:
                dic[i]=0
            else:
                dic[i]+=1
        i=0
        every_length= len (words[0] )
        all_length =len(words) * every_length
        
        dic2={}
        count1=0
        while ( i + all_length <= len(s) ):
            test=s[i:i+every_length]
            if test in dic:
                count1+=1
                dic2[count1]=i
                lst.append(s[i:i+all_length])
            i+=1   
        value=[]
        for  i in range (count1):
            print(i)
            flag=True
            count=0
            dic_reference={}
            start_position = count
            end_position = all_length
            while (start_position < end_position):
                start=lst[i][start_position:start_position+every_length]
                end=lst[i][end_position-every_length:end_position]
                if start not in dic or end not in dic:
                    flag=False
                    break
                if  end_position-start_position ==every_length :
                    if start in dic_reference:
                        dic_reference[start]+=1
                    else:
                        dic_reference[start]=0  
                else:         
                    if start in dic_reference:
                        dic_reference[start] +=1
                    else:
                        dic_reference[start]=0
                    
                    if end in dic_reference:
                        dic_reference[end] +=1
                    else:
                        dic_reference[end] =0
                if (dic_reference[start] > dic[start] ) or (dic_reference[end] > dic[end]) :
                    flag=False
                    break
                start_position += every_length
                end_position -=every_length
                
            if flag:
                if dic_reference==dic:
                    value.append(dic2[i+1])
        print(value)

import time
now=time.time()
#s = "wordgoodgoodgoodbestword"
s = "barfoothefoobarman"
words = ["foo","bar"]
s="a"

words=["a"]

#s ="abbaccaaabcabbbccbabbccabbacabcacbbaabbbbbaaabaccaacbccabcbababbbabccabacbbcabbaacaccccbaabcabaabaaaabcaabcacabaa"

#words =["cac","aaa","aba","aab","abc"]
#words = ["word","good","best","word"]
#s = "barfoothefoobarman"
#words = ["foo","bar"]
so=Solution()
a=so.findSubstring(s,words)
end=time.time()
print(end-now)

