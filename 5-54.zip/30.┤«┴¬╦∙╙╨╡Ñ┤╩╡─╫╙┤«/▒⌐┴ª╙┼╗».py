# -*- coding: utf-8 -*-
"""
Created on Sun Aug 18 23:13:05 2019

@author: zhazhi
"""
#1256
class Solution(object):
    def findSubstring(self, s, words):
        words_length=self.Series(words)
        dic={}
        for i in words:
            if i not in dic:
                dic[i]=1
            else:
                dic[i]+=1
        value=[]
        i=0
      #  print(len(s) -words_length)
        while (i<=len(s) -words_length):
            dic_reference={}
            count=0 
            for key in words:
                length =len(key)
                res=s[i+count:i+length+count]
             #   print(res,i,i+count,i+length+count)
                if res not in dic_reference:
                    dic_reference[res]=1
                else:
                    dic_reference[res] +=1
                count=count+length
            if dic_reference==dic:
                if i not in value:
                    value.append(i)
                
            i+=1
        print(value)

    def Series(self,words):
        res=''
        for i in range(len(words)):
            res=res+words[i]
        return len(res)
    
#s = "wordgoodgoodgoodbestword"
#s = "barfoothefoobarman"
#words = ["foo","bar"]

s = "aabbaabbaabb"
words = ["bb","aa","bb","aa","bb"]

#words = ["word","good","best","word"]

so=Solution()
a=so.findSubstring(s,words)
