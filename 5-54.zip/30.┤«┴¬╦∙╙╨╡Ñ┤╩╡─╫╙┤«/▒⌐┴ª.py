# -*- coding: utf-8 -*-
"""
Created on Thu Aug 15 20:12:43 2019

@author: zhazhi
"""
#1800
class Solution(object):
    def findSubstring(self, s, words):
        words_length=self.Series(words)
        lst=[]
        dic={}
        for i in words:
            if i not in dic:
                dic[i]=0
            else:
                dic[i]+=1
      #  print(dic)
        i=0
        while (i+words_length <= len(s)):
            lst.append(s[i:i+words_length])
            i+=1
        value=[]
        for i in range(len(lst)):
            dic_reference={}
            count=0
            for j in (words):
                length=len(j)
                if lst[i][count:count+length] in dic:
                    if lst[i][count:count+length] not in dic_reference:
                        dic_reference[lst[i][count:count+length]]=0
                    else:
                        dic_reference[lst[i][count:count+length]]+=1
                        
                    count=count+length
                    if dic==dic_reference:
                        if i not in value:
                            value.append(i)               
        print(value)
        
    def Series(self,words):
        res=''
        for i in range(len(words)):
            res=res+words[i]

        return len(res)
    
#s = "wordgoodgoodgoodbestword"
s = "aabbaabbaabb"
words = ["bb","aa","bb","aa","bb"]

#words = ["word","good","best","word"]
#s = "barfoothefoobarman"
#words = ["foo","bar"]
so=Solution()
a=so.findSubstring(s,words)
"""
        words_length=self.Series(words)
        lst=[]
        dic={}
        for i in range(len(words)):
            dic[words[i]]=i  #{'foo': 0, 'bar': 1}
        i=0
        
        
        while (i+words_length <= len(s)):
            lst.append(s[i:i+words_length])
            i+=1
        value=[]
        for i in range(len(lst)):
            count=0
            index=0
            for j in (words):
                length=len(j)
                if lst[i][count:count+length] in dic:
                  #  print(lst[i][count:count+length])
                    count=count+length
                    index+=1
                    
                    if index==len(words):
                        value.append(i)
                        index=0
        print(value )
"""
