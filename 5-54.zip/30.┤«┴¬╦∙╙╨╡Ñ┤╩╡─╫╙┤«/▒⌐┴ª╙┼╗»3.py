# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 19:02:15 2019

@author: zhazhi
"""
# 772
class Solution(object):
    def findSubstring(self, s, words):
        if not s or not words:
            return None
        dic={}
        for i in words:
            if i not in dic:
                dic[i]=1
            else:
                dic[i]+=1
        value=[]
        length1=len(words[0])
        words_length=len(words) *length1
        for i in range(len(s) - words_length  +1):
            res=s[i:i+length1]
            if res not in dic:
                continue
            else:
                dic_reference={}
                dic_reference[res]=1
                count=length1
                for _ in range(len(words) -1):
                    res=s[i+count:i+length1+count]
                    if res not in dic:
                        break
                    if res not in dic_reference:
                        dic_reference[res]=1
                    else:
                        dic_reference[res] +=1
                    count +=length1
                if dic_reference==dic:
                    if i not in value:
                        value.append(i)
        print(value)
                
#s = "wordgoodgoodgoodbestword"
#s = "barfoothefoobarman"
#words = ["foo","bar","the"]
s = "aabbaabbaabb"
words = ["bb","aa","bb","aa","bb"]
#s = "aabbaabbaabb"
#words = ["bb","aa","bb","aa","bb"]


#words = ["word","good","best","word"]

so=Solution()
a=so.findSubstring(s,words)
#print(a)