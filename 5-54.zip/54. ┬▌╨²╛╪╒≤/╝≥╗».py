# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 20:55:52 2019

@author: ACER
"""
class Solution(object):
    def spiralOrder(self, matrix):
        hang = len(matrix)
        if len(matrix)==0 or len(matrix[0])==0:
            return []
        lie  = len(matrix[0])
        hang = len(matrix)
        all_count = hang *lie
        start,end,tou,count = 0 ,0,0,0
        value=[]
        hang_heng,hang_back,lie_up,lie_down= True,False,False,False
        flag =False
        while (1):
            value.append(matrix[start][end])
            if lie_down:
                start+=1
            elif hang_heng:
                end+=1
            elif lie_up:
                start -=1
            elif hang_back:
                end -=1         
            count +=1
            # 2 shu
            if end == lie and start != hang :
                end -=1
                start +=1
                hang_heng,hang_back,lie_up,lie_down=False,False,False,True
            #  3
            if  (start == hang) and end == lie -1:
                start -=1
                end -=1  # the coner point
                hang_heng,lie_down,lie_up,hang_back=False,False,False,True
#             4
            if start == hang-1 and end == tou-1 :
                end +=1
                start -=1
                hang_heng,lie_down,hang_back,lie_up=False,False,False,True
                hang =hang-1
                lie = lie -1
                tou =tou+1
                flag =True
            if flag and start==tou-1:
                start+=1
                end +=1
                lie_up,lie_down,hang_back,hang_heng=False,False,False,True                 
            if count == all_count:
                break
        print(value)
#        print(value,start,end,tou)     
#        print(hang_heng,hang_back,lie_up,lie_down)
#        for i in sign:
#            print(i)
ss=Solution()
matrix=[[1,2,3],[4,5,6],[7,8,9],[10,11,12]]
#matrix=[]
#matrix=[[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16] ]
s=ss.spiralOrder(matrix)