# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 23:30:52 2019

@author: ACER
"""

class Solution(object):
    def spiralOrder(self, matrix):
        hang = len(matrix)
        if len(matrix)==0 or len(matrix[0])==0:
            return []
        lie  = len(matrix[0])
        hang = len(matrix)
        sign = [ [False for i in range(lie)] for j in range(hang) ]
        value=[]
        dx=[0,1,0,-1]        
        dy=[1,0,-1,0]
        r,c=0,0
        di=0
        for i in range (4):
            value.append(matrix[r][c])
            sign[r][c]=True
            cl,cr = r+dx[di],c+dy[di]
            if 0 <= cl < hang and 0 <= cr < lie and not sign[cl][cr]:
                r, c = cl, cr
            else:
                di = (di + 1) % 4  #  一共只有四个方向可以选择，走到拐点，选择方向。
                r, c = r + dx[di], c + dy[di]
        print(value)
matrix=[[1,2,3],[4,5,6],[7,8,9]]
#matrix=[]
#matrix=[[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16] ]
#matrix=[[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16] ]
ss=Solution()
s=ss.spiralOrder(matrix)