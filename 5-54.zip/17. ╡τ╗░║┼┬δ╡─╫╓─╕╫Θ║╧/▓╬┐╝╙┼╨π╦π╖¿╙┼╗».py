# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 21:06:17 2019

@author: zhazhi
"""



phone = {'2': ['a', 'b', 'c'],
                 '3': ['d', 'e', 'f'],
                 '4': ['g', 'h', 'i'],
                 '5': ['j', 'k', 'l'],
                 '6': ['m', 'n', 'o'],
                 '7': ['p', 'q', 'r', 's'],
                 '8': ['t', 'u', 'v'],
                 '9': ['w', 'x', 'y', 'z']}
                
def backtrack(combination, next_digits):  # 嵌套 2层
   # print(next_digits)
    if len(next_digits) == 0:
        output.append(combination)
    else:
        for letter in phone[next_digits[0]]:
            #print(next_digits[0])
            backtrack(combination + letter, next_digits[1:])

digits='23'                  
output = []
if digits:
    backtrack("", digits)
print(output)
