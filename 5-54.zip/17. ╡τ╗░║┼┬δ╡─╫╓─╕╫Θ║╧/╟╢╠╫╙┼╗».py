# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 22:59:49 2019

@author: zhazhi
"""
digits='234'
dic={'1':'*','2':'abc','3':'def','4':'ghi','5':'jkl','6':'mno','7':'pqrs','8':'tuv','9':'wxyz'}

result= list(dic[digits[0]])

#result = [x+y for x in result for y in dic[digits[i]]]
for i in range(1,len(digits)): # 总长
    result=[x+y  for x in result  for y in dic[digits[i]]   ]
            