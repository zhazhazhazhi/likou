# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 09:41:51 2019

@author: zhazhi
"""
digits="23"
#length=len(digits)
dic={'2':'abc','3':'def','4':'ghi','5':'jkl','6':'mno','7':'pqrs','8':'tuv','9':'wxyz'}

everytime_last=[]

original=[]

for n in digits:
    if n in dic:
        original.append(dic[n])
        
    else:
        print('*')

temp=[]
line =0

dp=[original[line]]


for k in range(len(digits) -1):
    count =0
    
    index=0
    everytime_last=[original[line+1]]
    
    if k==0:
        while(count<3):
            for i in range(3):
                count +=1
                for j in range(3):
                    temp.append ( dp[index][i]+everytime_last[0][j]  )
            if index < len(dp):
                index+=1
    else:
        for i in range(len(dp)):
            count +=1
            for j in range(3):
                temp.append ( dp[i]+everytime_last[0][j]  )
    dp=temp
    temp=[]  
    line +=1
    everytime_last=[]
print(dp)
