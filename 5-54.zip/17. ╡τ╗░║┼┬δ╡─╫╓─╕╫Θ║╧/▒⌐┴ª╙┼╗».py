# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 18:50:19 2019

@author: zhazhi
"""

digits="23"

dic={'1':'*','2':'abc','3':'def','4':'ghi','5':'jkl','6':'mno','7':'pqrs','8':'tuv','9':'wxyz'}

original=[]
temp=[]

for n in digits:
    if n in dic:
        original.append(dic[n])

dp=[original[0]]
for n in range(len(digits)-1):
    
    everytime_last=[original[n+1]]
    if n==0:
        length=len(dp[0])
        for i in range(length):
            for j in range(len(everytime_last[0])):
                temp.append ( dp[0][i]+everytime_last[0][j]  )    
    else:
        length=len(everytime_last[0])
        for i in range(len(dp)):
            for j in range(length):  #  最后一行的循环个数
                temp.append ( dp[i]+everytime_last[0][j]  )
    
    dp=temp
    temp=[]  
    print(dp)
    print(    )

