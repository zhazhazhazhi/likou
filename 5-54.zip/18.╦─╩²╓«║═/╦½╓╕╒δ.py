# -*- coding: utf-8 -*-
"""
Created on Tue Jul 30 20:48:03 2019

@author: zhazhi
"""
#nums=[-3,-2,-1,0,0,1,2,3]
nums=[-2,-1,-1,0,0,1]
target=-4
#nums=[1,0,-1,0,-2,2]
#target=0
nums.sort()

dp=[]
n=len(nums)
for i in range(n-3):
    if i>0 and nums[i]==nums[i-1]:
        continue
    if nums[i] + nums[i+1] + nums[i+2] + nums[i+3] > target:
        break
    if nums[i] + nums[n-1] + nums[n-2] + nums[n-3] < target:
        continue
    
    for j in range(i+1,n-2):
        if j - i > 1 and nums[j]==nums[j-1]:
            continue
        if nums[i] + nums[j] + nums[j+1] + nums[j+2] > target:
            break
        if nums[i] + nums[j] + nums[n-1] + nums[n-2] < target:
            continue
        left=j+1
        right=n-1
        while(left<right):
            sum1 = nums[i]+nums[left]+nums[right]+nums[j] -target
            if sum1==0:
                dp.append( [nums[i],nums[j],nums[left],nums[right]] )
                while (left<right) and(nums[left]==nums[left+1]):
                    left+=1
                while(left<right) and(nums[right]==nums[right-1]):
                    right-=1
                right-=1
            else:
                if sum1>=0:
                    right-=1
                else:
                    left+=1
                