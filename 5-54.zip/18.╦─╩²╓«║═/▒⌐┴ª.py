# -*- coding: utf-8 -*-
"""
Created on Mon Jul 29 19:34:05 2019

@author: zhazhi
"""
nums=[1,2,3,4,5,6,7]
target=16
#nums=[-3,-2,-1,0,0,1,2,3]

#target=1
nums.sort()
dp =[]

start=0
left=start+1

end= len(nums) -1
right = end-1

while((start +3 )<=end):
    sum1 = nums[start]+nums[left]+nums[right]+nums[end] -target
    if sum1 ==0:
        dp.append( [nums[start],nums[left],nums[right],nums[end]] )
        
    if  end -left==2:
        start =start+1
        left=start+1
        end= len(nums) -1
        right = end-1

    else:
        if sum1>=0:
            if left +1 >=right:
                end =end-1
                right = end-1
                left=start+1
            else:
                right -=1
        else:
            if left +1>=right :
                end =end-1
                right = end-1
                left=start+1
            else:
                left +=1



