# -*- coding: utf-8 -*-
"""
Created on Mon Jul 22 21:14:38 2019

@author: zhazhi
"""
#88ms
#x= "MCMXCIV" # 1994
x="MCMXCIX"
nums = [ 1000,  900, 500, 400,  100,  90,   50,  40,  10,    9,   5,    4,    1]
romans = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]

Hash ={ "M" : "1000" , "CM":"900" , "D":"500" , "CD":"400", "C":"100", "XC":"90", "L":"50",
       "XL":"40",  "X":"10", "IX":"9", "V":"5" , "IV":"4","I":"1"       }

res=0
index=0

if x in Hash:
    print(Hash[x])
else:
    while(index < len(x) ):
        if x[index:index+2] in Hash:
            res = res + int( Hash[x[index:index+2]])
            index +=2

        else:
            res =res + int(Hash[x[index]])
            index +=1
    print(res)
