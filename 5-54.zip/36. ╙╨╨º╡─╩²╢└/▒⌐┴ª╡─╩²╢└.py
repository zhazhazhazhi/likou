# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 15:47:34 2019

@author: zhazhi
"""

class Solution(object):
    def isValidSudoku(self, board):
        lie_dp=[ [False for i in range (9)] for j in range (9)  ]
        row_dp=[ [0 for i in range (9)] for j in range (9)  ]
        dic={'1':False,'2':1,'3':2,'4':3,'5':4,'6':5,'7':6,'8':7,'9':8}
        
        lie_count =0
        row_count =0
        while (lie_count<9):
            dic1=[]
            for i in range (lie_count,lie_count+3):
                for j in range (row_count,row_count+3):
                    left_value=board[i][j]
                    if left_value  in dic:
                        if lie_dp[i][ dic[left_value] ] != True:
                            lie_dp[i][dic[left_value] ] =True
                        else:
                            print('111')
                            return False
                        if left_value not in dic1:
                            dic1.append(left_value)
                        else:
                            print('222')
                            return False      
                    down_value = board[j][i]
                    if down_value  in dic:
                        if row_dp[dic[down_value]][ i] != True:
                            row_dp[dic[down_value] ][i] =True
                        else:
                            print('333')
                            return False   
            row_count +=3
            if row_count == 9:
                lie_count+=3
                row_count=0
        return True
                
                
ss=Solution()

"""
board=[["8","3",".",".","7",".",".",".","."],
       ["6",".",".","1","9","5",".",".","."],
       [".","9","8",".",".",".",".","6","."],
       ["8",".",".",".","6",".",".",".","3"],
       ["4",".",".","8",".","3",".",".","1"],
       ["7",".",".",".","2",".",".",".","6"],
       [".","6",".",".",".",".","2","8","."],
       [".",".",".","4","1","9",".",".","5"],
       [".",".",".",".","8",".",".","7","9"]]
"""




board=[[".",".",".", ".","5",".", ".","1","."],
       [".","4",".", "3",".",".", ".",".","."],
       [".",".",".", ".",".","3", ".",".","1"],
       
       ["8",".",".", ".",".",".", ".","2","."],
       [".",".","2", ".","7",".", ".",".","."],
       [".","1","5", ".",".",".", ".",".","."],
       
       [".",".",".", ".",".","2", ".",".","."],
       [".","2",".", "9",".",".", ".",".","."],
       [".",".","4", ".",".",".", ".",".","."]]

board=[["5","3",".", ".","7",".", ".",".","."],
       ["6",".",".", "1","9","5", ".",".","."],
       [".","9","8", ".",".",".", ".","6","."],
       
       ["8",".",".", ".","6",".", ".",".","3"],
       ["4",".",".", "8",".","3", ".",".","1"],
       ["7",".",".", ".","2",".", ".",".","6"],
       
       [".","6",".", ".",".",".", "2","8","."],
       [".",".",".", "4","1","9", ".",".","5"],
       [".",".",".", ".","8",".", ".","7","9"]]

s=ss.isValidSudoku(board)
print(s)



