# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 16:58:19 2019

@author: ACER
"""

class Solution(object):
    def jump(self, nums):
        now_pos = nums[0]
        pre_pos = nums[0]
        step=1
        for i in range (len(nums)):
            if i > now_pos: #  超过 跳的最远的地方，加一，将上一个最大给现在
                step +=1
                now_pos=pre_pos
           # nums[i]+i 是跳的最远的地方
            if pre_pos < nums[i]+i:  #  当先前最大 小于目前这个值能到达的最远的地方
                pre_pos = nums[i]+i  # 更新 最大
          #  print(pre_pos,i,nums[i]+i)
        return step 
            
        
ss=Solution()
#nums=[2,3,1,1,4]
nums=[5,9,3,2,1,0,2,3,3,1,0,0]
#nums=[1,1,1,1,1]
s=ss.jump(nums)
print(s)