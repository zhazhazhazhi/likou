# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 16:27:06 2019

@author: ACER
"""

class Solution(object):
    def jump(self, nums):
        end=0
        maxPosition = 0
        step=0
        for i in range (len(nums)-1):
            maxPosition=max(maxPosition,nums[i] + i)
            if i==end:
                end = maxPosition
                step +=1
        print(step)
ss=Solution()
#nums=[2,3,1,1,4]
nums=[5,9,3,2,1,0,2,3,3,1,0,0]
s=ss.jump(nums)