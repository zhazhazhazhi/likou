# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 16:11:37 2019

@author: ACER
"""

class Solution(object):
    def jump(self, nums):
        m = len(nums)
        if m == 1: 
            return 0
        q = [(0, 0)]
        visited = [False] * m
        while q:
            level, curi = q.pop(0)
            for i in range(nums[curi], 0, -1):
                if curi + i >= m-1:
                    return level + 1
                if not visited[curi+i]:
                    q.append((level+1, curi+i))
                    visited[curi+i] = True
ss=Solution()
#nums=[2,3,1,1,4]
#nums=[5,9,3,2,1,0,2,3,3,1,0,0]
nums=[1,1,1,1,1]
s=ss.jump(nums)
print(s)