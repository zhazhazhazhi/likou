# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 21:20:55 2019

@author: zhazhi
"""
brackets="()"
stack =[]

total={"(":0, "[":1, "{":2,")":3, "]":4, "}":5}

mapping ={")":"(",  "]":"[",  "}":"{"  }


count=0
for char in brackets:
    if char in mapping:
        if stack:
            if mapping[char] == stack[count-1]:
                b=stack.pop()
                print(b)
                count-=1
            else:
                print(False)
        else:
            print(False)
            break
    else:
        count+=1
        stack.append(char)

if len(stack)==0:
    print(True)
else:
    print(False)
#top_element = stack.pop() if stack else '#'
