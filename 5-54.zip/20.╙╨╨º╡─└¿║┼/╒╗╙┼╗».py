# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 21:20:55 2019

@author: zhazhi
"""
brackets=")()())"
stack =[]

total={"(":0, "[":1, "{":2,")":3, "]":4, "}":5}

mapping ={")":"(",  "]":"[",  "}":"{"  }



for char in brackets:
    if char in mapping:
        if stack:
            element=stack.pop()
        else:
            element='#'
        if element != mapping[char]:
            print(False)
    else:
        stack.append(char)

if len(stack)==0:
    print(True)
else:
    print(False)
#top_element = stack.pop() if stack else '#'
