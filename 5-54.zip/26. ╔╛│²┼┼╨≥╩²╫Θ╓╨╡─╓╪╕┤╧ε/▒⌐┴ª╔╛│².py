# -*- coding: utf-8 -*-
"""
Created on Sun Aug 11 16:04:26 2019

@author: zhazhi
"""

class Solution(object):
    def removeDuplicates(self, nums):
        length=len(nums)
        if length==0:
            return 0
        index=nums[0]
        count =1
        while (count < length):  
            if index == nums[count]:
                nums.pop(count)
            else:
                index=nums[count]
                count +=1
            length=len(nums)
        return nums



s=Solution()

#nums= [0,0,1,1,1,2,2,3,3,4,4,4,4,5,6,6,6,6,6,6,6]
nums=[0,0,1,1,1,2,2,3,3,4]
a=s.removeDuplicates(nums) 
print(a)