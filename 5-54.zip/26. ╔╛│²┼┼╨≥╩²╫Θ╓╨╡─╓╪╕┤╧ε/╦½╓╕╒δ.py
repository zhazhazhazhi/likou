# -*- coding: utf-8 -*-
"""
Created on Sun Aug 11 20:34:32 2019

@author: zhazhi
"""
# 
class Solution(object):
    def removeDuplicates(self, nums):
        if not nums: return 0
        i=1
        n = len(nums)
        for j in range(1, n):
            if nums[j] != nums[j-1]:
                nums[i] = nums[j]
                i+=1
        print(nums[:i])


s=Solution()

#nums= [0,0,1,1,1,2,2,3,3,4,4,4,4,5,6,6,6,6,6,6,6]
#nums=[0,0,1,1,1,2,2,3,3,4]
nums=[1,1,2,2]
s.removeDuplicates(nums) 
#print(a)