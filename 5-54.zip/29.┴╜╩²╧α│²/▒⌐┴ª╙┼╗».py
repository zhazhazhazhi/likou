# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 10:38:12 2019

@author: zhazhi
"""

class Solution:
    def divide(self, dividend: int, divisor: int) -> int:
        if divisor ==0:
            return -1
        plus=1
        if (dividend <0 and divisor>0) or (dividend >0 and divisor<0):
            plus=-1
            
        abs_dividend=abs(dividend)
        abs_divisor=abs(divisor)
        count=-1
        assistance=abs_divisor
        lst=[]
        lst.append(abs_divisor)
        all_count=0
        while (abs_dividend>=abs_divisor):
            count+=1
            abs_dividend=abs_dividend-abs_divisor
            abs_divisor=abs_divisor+abs_divisor
            lst.append(abs_divisor)
            all_count=all_count+pow(2,count)
            if (abs_dividend < abs_divisor):
                while (abs_dividend >= assistance ):
                    for j in range(len(lst)-1,-1,-1):
                        count+=1
                        if lst[j] <= abs_dividend:
                            abs_dividend  =abs_dividend-lst[j]
                            all_count=all_count+pow(2,j)
                        else:
                            continue
        print('总的循环次数',count)
   #     print(all_count)
        if plus ==-1:
            all_count= -all_count
        if all_count >= (2**31) -1   :
            return  (2**31 -1)
        if all_count<= -(2**31):
            return -(2**31 )
        return all_count        

        
        
        
            
import time
now=time.time()
s=Solution()
dividend =100000000000000000000000000000000000000000000000000000
divisor = 1
a=s.divide(dividend,divisor)
print(a)
end=time.time()
print(end-now)