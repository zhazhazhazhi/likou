# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 22:54:41 2019

@author: zhazhi
"""

class Solution:
    def divide(self, dividend: int, divisor: int) -> int:
        if divisor ==0:
            return -1
        if (dividend <0 and divisor>0) or (dividend >0 and divisor<0):
            plus=-1
        else:
            plus=1
        abs_dividend=abs(dividend)
        abs_divisor=abs(divisor)
        count=0
        assistance=abs_divisor
        lst=[]
        all_count=0
        lst.append(assistance)
        while (abs_dividend>=abs_divisor):
            count+=1
            abs_dividend=abs_dividend-abs_divisor
            abs_divisor=abs_divisor+assistance
            all_count+=count
            lst.append(abs_divisor)
            if abs_dividend<=abs_divisor:
                while (abs_dividend >=assistance ):
                    for j in range(len(lst)-1,-1,-1):
                        if lst[j]<=abs_dividend:
                            abs_dividend=abs_dividend-lst[j]
                            all_count=all_count+j+1
                        else:
                            continue
        if plus ==-1:
            all_count= -all_count
        if all_count >= (2**31) -1   :
            return  (2**31 -1)
        if all_count<= -(2**31):
            return -(2**31 )
        return all_count
      #  print(2**31)
        
            
import time
now=time.time()
s=Solution()
dividend = -100000000000
divisor = 2
a=s.divide(dividend,divisor)
print(a)
end=time.time()
print(end-now)