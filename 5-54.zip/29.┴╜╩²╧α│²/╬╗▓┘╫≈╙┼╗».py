# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 18:35:45 2019

@author: zhazhi
"""

class Solution:
    def divide(self, dividend: int, divisor: int) -> int:
        #位移操作
        if  not divisor:
            return -1
        plus=1
        if (dividend <0 and divisor>0) or (dividend >0 and divisor<0):
            plus=-1
        dividend=abs(dividend)
        divisor=abs(divisor)
        count=0
        while (dividend>=divisor):
            count+=1
            divisor<<=1
        result=0
        while (count>0):
            count -=1
            divisor>>=1
            if (dividend >= divisor):
                result =result+  (1<<count)
                dividend=dividend-divisor
        if plus==-1:
            result=-result
        if result >= (2**31) -1   :
            return  (2**31 -1)
        if result<= -(2**31):
            return -(2**31 )
        return result       
                    
                    
import time           
now=time.time()
s=Solution()
dividend =100
divisor = 2
a=s.divide(dividend,divisor)
#print(a)
end=time.time()
#print(end-now)
