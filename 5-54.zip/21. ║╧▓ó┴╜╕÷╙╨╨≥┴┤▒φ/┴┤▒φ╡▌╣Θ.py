# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 21:13:53 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None

def creatlist(nums):
    last=None
    for num in reversed (nums):
        node=ListNode(num)
        node.next=last
        last = node
    return last


class Solution:
    def mergeTwoLists(self, l1: ListNode, l2: ListNode) -> ListNode:
        if (l1==None):
            return l2
        if (l2==None):
            return l1
        
        if (l1.val<l2.val):
            l1.next=self.mergeTwoLists(l1.next,l2)  #  每次传入的是下一个l1 和现在的l2
            return l1
        else:
            l2.next=self.mergeTwoLists(l1,l2.next) # 每次传入的是现在l1 和下一个的l2
            return l2
    
    def print_list(self,node):
        while(node):
            print(node.val)
            node=node.next





if __name__=="__main__":
    l11=[1,3,5]
    l22=[2,4,6]
    l1=creatlist(l11)
    l2=creatlist(l22)
    s=Solution()
    a=s.mergeTwoLists(l1,l2)
    print(s.print_list(a))
    
    