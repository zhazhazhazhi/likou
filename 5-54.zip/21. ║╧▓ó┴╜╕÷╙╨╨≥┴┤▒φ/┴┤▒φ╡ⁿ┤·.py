# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 23:06:37 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None

def creatlist(nums):
    last=None
    for num in reversed(nums):
        node=ListNode(num)
        node.next=last
        last=node
    return last

class Solution:
    def mergeTwoLists(self, l1: ListNode, l2: ListNode) -> ListNode:
        prehead = ListNode(-1)
        prev = prehead
        prehead=prehead.next
        while(l1 and l2):
            if (l1.val<=l2.val):
                prev.next=l1
                l1=l1.next
            else:
                prev.next=l2
                l2=l2.next
            prev=prev.next
            
        prev.next = l1 if l1 is not None else l2
        
        return prehead
    
    
    
    
    def print_list(self,node):
        while(node):
            print(node.val)
            node=node.next


if __name__=="__main__":
    l11=[1,2,4]
    l12=[1,2,3]
    l1=creatlist(l11)
    l2=creatlist(l12)    
    s=Solution()
    a=s.mergeTwoLists(l1,l2)
    print(s.print_list(a))



        