# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 20:24:44 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.data=x
        self.next=None



        
def create_list(nums):
    last = None
    for num in reversed(nums):
        list_node = ListNode(num)
        list_node.next = last
        last = list_node
    return last

class Solution:
    def mergeTwoLists(self, l1: ListNode, l2: ListNode) -> ListNode:
        if l1==None and l2==None:
            return l1
        if l1==None or l2==None:
            return l1 or l2
        re=ListNode(0)
        r1,r2=l1,l2
        if l1.data<l2.data:
            re.next=l1
        else:
            re.next=l2
        while( 1  ):
            if (l1.data<l2.data):
                if l1.next ==None:
                    l1=l1
                    r1.next=l2
                    break
                else:
                    l1=l1.next
                r1.next=l1 if l1.data <l2.data else l2
                r1=l1
            else:
                if l2.next ==None:
                    l2=l2
                    r2.next=l1
                    break
                else:
                    l2=l2.next
                    # 增加了一个等于
                r2.next=l2 if l2.data <=l1.data  else l1  
              #  if l2.data <=l1.data   
              #       r2.next=l2
              #  else:
             #       r2.next=l1
                r2=l2
        #    print(l2.data,l1.data)
            if l1.next==None and l2.next==None:
                if l1.data>=l2.data:  # 增加了一个等于
                    r2.next=l1
                    break
                else:
                    r1.next=l2
                    break
        return   re.next
        
    
    def printnode(self,node):
        while(node):
            print(node.data,'  ',end='')
            node=node.next
        


if __name__ == "__main__":
    l11=[1,2,3]
    l12=[1,2,3]
    l1=create_list(l11)
    l2=create_list(l12)
    s=Solution()
    a=s.mergeTwoLists( l1, l2 )
    print(s.printnode(a))
    

