# -*- coding: utf-8 -*-
"""
Created on Sun Aug 11 23:38:17 2019

@author: zhazhi
"""

class Solution(object):
    def removeElement(self, nums, val):
        length=len(nums)
        n=0
        for i in range(length):
            if nums[i] !=val:
                nums[n]=nums[i]
                n+=1
            
        return n
        
        
        

s=Solution()
nums =  [3,2,2,3]
val=3
a=s.removeElement(nums,val)
print(a)