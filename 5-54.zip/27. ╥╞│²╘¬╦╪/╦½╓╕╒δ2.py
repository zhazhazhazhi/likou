# -*- coding: utf-8 -*-
"""
Created on Sun Aug 11 23:11:22 2019

@author: zhazhi
"""

class Solution(object):
    def removeElement(self, nums, val):
        length=len(nums)
        i=0
       # for i in range(length):
        while (i < length):
            if nums[i] ==val:
                nums[i]=nums[length-1]
                length-=1
            else:
                i+=1
            
        return length
        
        
        

s=Solution()
nums = [0,1,2,2,3,0,4,2]
val=2
a=s.removeElement(nums,val)
print(a)