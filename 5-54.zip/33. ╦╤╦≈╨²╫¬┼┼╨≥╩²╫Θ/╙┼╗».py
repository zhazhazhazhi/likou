# -*- coding: utf-8 -*-
"""
Created on Sun Sep  1 19:33:59 2019

@author: zhazhi
"""

class Solution(object):
    def search(self, nums, target):
        if not nums :
            return -1
        length=len(nums)
        min_index=nums.index(min(nums))
        if nums[0] <=target and nums[min_index-1] >= target:
            if min_index ==0:
                index=self.compute(nums)
                return index
            else:
                index=self.compute(nums[:min_index])
                return index
        elif nums[min_index] <= target and nums[length-1] >= target:
            index=self.compute(nums[min_index:length])
            if index == -1:
                return -1
            index=len(nums[:min_index])+index
            return index
        else:
            return -1
    # 二分法
    def compute(self,num):
        length=len(num)
        left,right = 0,length-1
        while (left<=right):
            mid= (left+right)//2
            if target > num[mid]:
                left = mid +1
            elif target < num[mid]:
                right =mid-1
            else:       
                return mid
        return -1

ss=Solution()
#nums = [10,11,12,13,0,1,2,3,5,6,7,8]

#nums=[2,3,4,5,6,7,8,9,1]
nums=[5,1,3]

target = 5
a=ss.search(nums,target)
print(a)
