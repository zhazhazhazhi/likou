# -*- coding: utf-8 -*-
"""
Created on Sat Aug 31 21:31:42 2019

@author: zhazhi
"""

class Solution(object):
    def search(self, nums, target):
        if not nums :
            return -1
        length=len(nums)
        start=0
        min_index=nums.index(min(nums))
        index=0
        if nums[start] <=target and nums[min_index-1] >= target:
            if min_index ==0:
             #   print(111)
                index=self.compute(nums)
                return index
            else:
            #    print(222)
                index=self.compute(nums[start:min_index])
                return index
           
        elif nums[min_index] <= target and nums[length-1] >= target:
         #   print(333)
            index=self.compute(nums[min_index:length])
            if index == -1:
                return -1
            index=len(nums[:min_index])+index
            return index
        else:
            return -1
    # 二分法
    def compute(self,num):
        length2=len(num)
        left,right = 0,length2-1
        while (left<=right):
            mid= (left+right)//2
            if target > num[mid]:
                left = mid +1
            elif target < num[mid]:
                right =mid-1
            else:       
                return mid
        return -1


ss=Solution()
#nums = [10,11,12,13,0,1,2,3,5,6,7,8]

nums=[2,3,4,5,6,7,8,9,1]
#nums=[5,1,3]


target = 1
a=ss.search(nums,target)
print(a)
