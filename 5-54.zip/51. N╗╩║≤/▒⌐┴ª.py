# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 16:34:41 2019

@author: ACER
"""
# 不同行，不同列，不在同一条斜线  ,相当于 米字形不可以
class Solution(object):
    def solveNQueens(self, n):
        dp=[ ["." for i in range(n)] for j in range(n) ]
        take=[[False for i in range(n)] for j in range(n)]
        sign = True
        select=[]
        for l in range (n):
            select.append([])
            
        for i in range(n):
            for j in range(n):
                select[0].append((i,j))
            break
        back_pop=[]
        hang = 0
        sign = True
        queen_count =0
        value = []
        test =0
        select,dp,hang,queen_count,sign,take,back_pop=self.update_first(select,dp,hang,queen_count,sign,back_pop,test)
        flag =True
        
        ##############################################
        ##############################################
        ##############################################
        m=68
        for test in range(69):  #18
#        while (flag):
            
            if len(select[hang])==0 :
                hang,queen_count,dp,select=self.back(take,select,back_pop,dp,sign,hang,n,queen_count,test)
     
            k = select[hang].pop(0)
            i,j=k
            sign,dp,hang,queen_count=self.write(i,j,dp,hang,sign,queen_count)
            back_pop.append(k)

#                for l in dp:
#                    print(l)
#                print()
#                for l in take:
#                    print(l)
#                print()
            if queen_count == n:
                for l in dp:
                    l = "".join(l)
                    value.append(l)
                hang = hang -1
              #  self.printsomething(dp,select,hang) 
            else:
#                print(test)
#                if m ==test:
#                    for l in take:
#                        print(l)
#                    print()
                take=self.check1(dp,n,sign,test)

#                if m ==test:
#                    for l in take:
#                        print(l)
                select=self.unwrite(dp,n,take,select,hang)


#            if m ==test:
#                print("##########test的值##########",test)
#              #  self.printsomething(dp,select,hang) 
#                for l in dp:
#                    print(l)
#                print()
#                for l in take:
#                    print(l)
#                print()


            
            if len(select[0])==0:
                count1=1
                for l in range(1,n):
                    if len(select[l]) ==0:
                        count1 +=1
                    else:
                        break
                if count1 ==n:
                    flag = False

        #############################################
        ##############################################
        ##############################################
        
#        count = 0 
#        dp=[]
#        take=[]
#
#        for l in value:
#            l="".join(l)
#            dp.append(l)
#            count +=1
#            if count ==n:
#                take.append(dp)
#                count =0
#                dp=[]
#        for l in take:
#            print(l)
#        print(len(take) )
        
        
    def printsomething(self,dp,select,hang):
        print()
        print("#########开始#######")
        for l in dp:
            print(l)
        print("行是",hang)
        for l in select:
            print(l)     
        print("#########结束#######")
        print()
                            
    def update_first(self,select,dp,hang,queen_count,sign,back_pop,test):
        dp=[ ["." for i in range(n)] for j in range(n) ]
        queen_count=0
        hang=0
        k= select[hang].pop(0)
        back_pop.append(k)
        for l in range(hang+1,n):
            select[l]=[]
        i,j = k
        sign,dp,hang,queen_count=self.write(i,j,dp,hang,sign,queen_count)
        take=self.check1(dp,n,sign,test)
        self.unwrite(dp,n,take,select,hang)
        return select,dp,hang,queen_count,sign,take,back_pop

                     
    def back(self,take,select,back_pop,dp,sign,count,n,queen_count,test):
        sign =False
        
        if len(back_pop) == n:
            
            flag1 = True
        else:
            flag1=False
        for l in range(count,-1,-1):
            if len(back_pop) !=0:
                if len(select[l])==0:
                    i,j=back_pop.pop()
                    dp[i][j]="."
                    count-=1  
                    queen_count -=1
                    select[l]=[]
                else:
                    if flag1:
                        k=back_pop.pop()
                        i,j=k
                        dp[i][j]="."
                        queen_count -=1
                    self.check1(dp,n,sign,test)
                    break
        
        for l in range(n-1,0,-1):
            if l==1 and len(select[l])==0:
                select,dp,count,queen_count,sign,take,back_pop=self.update_first(select,dp,count,queen_count,sign,back_pop)
            else:
                break
        return count,queen_count,dp,select

    def write(self,i,j,dp,count,sign,queen_count):
        dp[i][j]="Q"
        count +=1
        sign=True
        queen_count+=1
        return sign,dp,count,queen_count
            
    def unwrite(self,dp,n,take,select,count):
        for i in range(count,count+1):
          #  print(i)
            for j in range(n):
                if take[i][j]:
                    continue
                else:   
                    select[count].append((i,j))
        return select

    # 里面有Q的所有米字形 放True
    
    def check1(self,dp,n,sign,test):
        
        take=[[False for i in range(n)] for j in range(n)]
        for i in range(n):
            for j in range(n):
                if dp[i][j]=="Q":
                    take=self.check(dp,take,n,i,j,sign,test)
        return take

    def check(self,dp,take,n,i,j,sign,test):
      #  print(test)
        m = 68

        count ,count1,count2=0,0,0
        for k in range(n):
            if dp[i][k]=="Q":
                count +=1
            take[i][k]=sign
                
        for k in range(n):
            if dp[k][j] == "Q":
                count1+=1
            take[k][j]=sign

        if i ==0 or j ==0:
            first_i,first_j = i , j
            while (first_i<n-1 and first_j<n-1): 
                if dp[first_j+1][first_j+1]=="Q":
                    count2 +=1  
                first_i +=1
                first_j +=1
                take[first_i][first_j] =sign
                
            first_i,first_j = i , j
            #   you
            if i==0:
                while ( first_j!=0):
                    if dp[first_i+1][first_j-1]=="Q":
                        count2 +=1
                    first_i +=1
                    first_j -=1 
                    take[first_i][first_j] =sign  
            # zuo
            if j ==0:
                while (first_i != 0):
                    if dp[first_i-1][first_j+1]=="Q":
                        count2 +=1
                    first_i -=1
                    first_j +=1  
                    take[first_i][first_j] =sign

        else:
            first_i,first_j = i , j
            count2 =0
            # y= -kx+b
            while (first_i!=0 and first_j !=0): 
                if dp[first_i-1][first_j-1] =="Q":
                    count2 +=1
                first_i -=1
                first_j -=1
                take[first_i][first_i] =sign  

            last_i,last_j = i , j
            while (last_i< n-1 and last_j<n-1):
                if dp[last_i+1][last_j+1] =="Q":
                    count2 +=1
                last_i +=1
                last_j +=1  
                take[last_i][last_j] =sign


            # 另一条直线  up  y=kx+b
            last_i,last_j = i , j
       #     count2 =0
            while ( first_j < n-1):
                if dp[first_i-1][first_j+1] =="Q":
                    count2 +=1
                first_i -=1
                first_j +=1
                take[last_i][last_j] =sign
            last_i,last_j = i , j
            
            if m == test:
                for l in take:
                    print(l)
                print()
           # down
            while (last_i< n-1 ):
                if dp[last_i+1][last_j-1] =="Q":
                    count2 +=1
                last_i +=1
                last_j -=1         
                take[last_i][last_j] =sign
            if m == test:
                for l in take:
                    print(l)
                print()

#        if m == test:
#            print("####################")
#            for l in take:
#                print(l)
#            print()
        return take

  
ss=Solution()
n=7
s=ss.solveNQueens(n)
