# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 15:28:03 2019

@author: ACER
"""

from copy import deepcopy

class Solution(object):
    def solveNQueens(self, n):
        if n <4:
            return []
        select=[]
        for l in range (n):
            select.append([])
            if l==0:
                for j in range(n):select[0].append((l,j))     
            else:continue   
        dp=[ ["." for i in range(n)] for j in range(n) ]
        queen_count,hang=0,0
        back_pop=[]
        temp=[]  
        dic_fu,dic1_zhu={},{}
        take=[[True for i in range(n)] for j in range(n)]
        for i in range (2*n-1):dic_fu[i]=[]
        for i in range (-1*n+1,n,1):dic1_zhu[i]=[]     
        for i in range(n):
            for j in range(n):
                dic_fu[j+i].append((i,j))     
                dic1_zhu[j-i].append((i,j))
        m = 0
        i,j=0,0
        Q_lie, Q_hang=[], []
        a=self.test_back(select,back_pop,dp,hang,n,queen_count,dic_fu,dic1_zhu,temp,m,take,i,j,Q_lie, Q_hang)
        print(a)
#        
    def test_back(self,select,back_pop,dp,hang,n,queen_count,dic_fu,dic1_zhu,temp,m,take,i,j,Q_lie, Q_hang):
        if len(select[hang])==0   :
            print("############返回############")
            hang,queen_count,dp,select,take,Q_lie, Q_hang=self.back(select,back_pop,dp,hang,n,queen_count,take,i,j,Q_lie, Q_hang)  
#            take=[[False for i in range(n)] for j in range(n)]

        k = select[hang].pop(0)
        i,j=k
        dp,hang,queen_count=self.write(i,j,dp,hang,queen_count)
        Q_hang.append(i)
        Q_lie.append(j)
        back_pop.append(k)
        if queen_count == n:
            value = []
            for l in dp:value.append("".join(l))    
            temp.append(value)
            hang = hang -1 
        else:
            sign=False
            take=self.check1(n,i,j,take,sign,Q_lie,Q_hang)
            select,take=self.unwrite(n,select,hang,take,i,j,Q_lie,Q_hang)
        m +=1
        if m ==11:   
            for l in select:
                print(l)
            print()
            for l in dp:
                print(l)
            print()
#            for l in take:
#                print(l)
#            print()
            return  temp
        temp=self.test_back(select,back_pop,dp,hang,n,queen_count,dic_fu,dic1_zhu,temp,m,take,i,j,Q_lie, Q_hang)
        return temp
        
    def back(self,select,back_pop,dp,count,n,queen_count,take,i,j,Q_lie, Q_hang):
        flag1=False
        if len(back_pop) == n: flag1 = True 
        for l in range(count,-1,-1):
            if len(back_pop) !=0:
                if len(select[l])==0:
                    i,j=back_pop.pop()
                    Q_hang.pop()
                    Q_lie.pop()
                    dp[i][j]="."
                    count-=1  
                    queen_count -=1
                    select[l]=[]
                else:
                    if flag1:
                        i,j=back_pop.pop()
                        dp[i][j]="."
                        queen_count -=1
                    break
        if j != n-1:
            take[i+1][j+1] =  False
        if j >0:
            take[i+1][j-1] =  False
        return count,queen_count,dp,select,take,Q_lie, Q_hang

    def write(self,i,j,dp,count,queen_count):
        dp[i][j]="Q"
        count +=1
        queen_count+=1
        return dp,count,queen_count
            
    def unwrite(self,n,select,count,take,i,j,Q_lie,Q_hang):
        print("################# start ##################")  
        for l in take:
            print(l)
        
        for _ in range(count,count+1):
            for __ in range(n):
                if not take[_][__] and __ not in Q_lie and _ not in Q_hang :
                    select[count].append((_,__)) 
                  
        for l in select:
            print(l)
            
            
        print("################# end ##################")  
              
        sign =True
        take=self.check1(n,i,j,take,sign,Q_lie,Q_hang)
        return select,take
    # 里面有Q的所有米字形 放True
    def check1(self,n,i,j,take,sign,Q_lie,Q_hang):

        for k in range(n):
            if k == j-1 or k == j or k == j+1 or k in Q_lie:
                continue
            else:
                take[i+1][k]=sign
        return take


import time
now=time.time()
ss=Solution()
n=5
s=ss.solveNQueens(n)
end=time.time()
print(end-now)
