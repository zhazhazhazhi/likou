# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 16:36:36 2019

@author: ACER
"""
class Solution(object):
    def solveNQueens(self, n):
        if n <4:
            return []
        select=[]
        for l in range (n):
            select.append([])
            if l==0:
                for j in range(n):select[0].append((l,j))     
        dp=[ ["." for i in range(n)] for j in range(n) ]
        queen_count,hang=0,0
        back_pop=[]
        temp=[]  
        Q_dif=[] # j-i
        Q_sum=[] #j+i
        m = 0
        i,j=0,0
        Q_lie, Q_hang=[], []
        a=self.test_back(select,back_pop,dp,hang,n,queen_count,temp,m,i,j,Q_lie, Q_hang,Q_dif ,Q_sum)
        
        print(len(a))
#        
    def test_back(self,select,back_pop,dp,hang,n,queen_count,temp,m,i,j,Q_lie, Q_hang,Q_dif ,Q_sum):
        if len(select[hang])==0   :
#            print("############返回############")
            hang,queen_count,dp,select,Q_lie, Q_hang,Q_dif ,Q_sum=self.back(select,back_pop,dp,hang,n,queen_count,i,j,Q_lie, Q_hang,Q_dif ,Q_sum)  
            
        k = select[hang].pop(0)
        i,j=k
        dp,hang,queen_count=self.write(i,j,dp,hang,queen_count)
        Q_hang.append(i)
        Q_lie.append(j)
        
        Q_dif.append(j-i)
        Q_sum.append(j+i)
        
        back_pop.append(k)
        if queen_count == n:
            value = []
            for l in dp:value.append("".join(l))    
            temp.append(value)
            hang = hang -1 
        else:
            select=self.unwrite(n,select,hang,Q_lie,Q_hang,Q_dif,Q_sum)
        m +=1
        if len(select[0])==0:
            
            count1=1
            for l in range(1,n):
                if len(select[l]) ==0:count1 +=1
                else:break             
            if count1 ==n:
                return temp
        self.test_back(select,back_pop,dp,hang,n,queen_count,temp,m,i,j,Q_lie, Q_hang,Q_dif ,Q_sum)
        return temp
        
    def back(self,select,back_pop,dp,count,n,queen_count,i,j,Q_lie, Q_hang,Q_dif ,Q_sum):
        flag1=False
        if len(back_pop) == n: flag1 = True 
        for l in range(count,-1,-1):
            if len(back_pop) !=0:
                if len(select[l])==0:
                    back_pop.pop()
                    Q_hang.pop()
                    Q_lie.pop()
                    Q_dif.pop()
                    Q_sum.pop()
                    dp[i][j]="."
                    count-=1  
                    queen_count -=1
                    select[l]=[]
                else:
                    if flag1:
                        back_pop.pop()
                        Q_hang.pop()
                        Q_lie.pop()
                        Q_dif.pop()
                        Q_sum.pop()
                        dp[i][j]="."
                        queen_count -=1
                    break
        return count,queen_count,dp,select,Q_lie, Q_hang,Q_dif ,Q_sum

    def write(self,i,j,dp,count,queen_count):
        dp[i][j]="Q"
        count +=1
        queen_count+=1
        return dp,count,queen_count
            
    def unwrite(self,n,select,count,Q_lie,Q_hang,Q_dif ,Q_sum):    
        for _ in range(count,count+1):
            for __ in range(n):
                if  __ not in Q_lie and _ not in Q_hang and __-_ not in Q_dif and __+_ not in Q_sum:
                    select[count].append((_,__)) 
        return select

import time
now=time.time()
ss=Solution()
n=5
s=ss.solveNQueens(n)
end=time.time()
print(end-now)
