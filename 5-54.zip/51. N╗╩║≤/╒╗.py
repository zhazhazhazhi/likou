# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 10:44:54 2019

@author: ACER
"""

class Solution(object):
    def solveNQueens(self, n):
        if n <4:
            return []
        select=[]
        for l in range (n):
            select.append([])
            if l==0:
                for j in range(n):select[0].append((l,j))    
            else:continue   
        dp=[ ["." for i in range(n)] for j in range(n) ]
        queen_count,hang=0,0
        back_pop=[]
        temp=[]
#        for test in range(1):       
        while (True):
            if len(select[hang])==0   :
                hang,queen_count,dp,select=self.back(select,back_pop,dp,hang,n,queen_count)
            k = select[hang].pop(0)
            i,j=k
            dp,hang,queen_count=self.write(i,j,dp,hang,queen_count)
            back_pop.append(k)
            if queen_count == n:
                value = []
                for l in dp:
                    l = "".join(l)
                    value.append(l)    
                temp.append(value)
                hang = hang -1 
            else:
                take=self.check1(dp,n,back_pop)
                select=self.unwrite(n,take,select,hang)
            if len(select[0])==0:
                count1=1
                for l in range(1,n):
                    if len(select[l]) ==0:
                        count1 +=1
                    else:
                        break
                if count1 ==n:
                    break
#        for l in temp:
#            print(l)
            
        print(len(temp))
      
    def back(self,select,back_pop,dp,count,n,queen_count):
        flag1=False
        if len(back_pop) == n:
            flag1 = True
        for l in range(count,-1,-1):
            if len(back_pop) !=0:
                if len(select[l])==0:
                    i,j=back_pop.pop()
                    dp[i][j]="."
                    count-=1  
                    queen_count -=1
                    select[l]=[]
                else:
                    if flag1:
                        i,j=back_pop.pop()
                        dp[i][j]="."
                        queen_count -=1
                    break
        return count,queen_count,dp,select

    def write(self,i,j,dp,count,queen_count):
        dp[i][j]="Q"
        count +=1
        queen_count+=1
        return dp,count,queen_count
            
    def unwrite(self,n,take,select,count):
        for i in range(count,count+1):
            for j in range(n):
                if take[i][j]:
                    continue
                else:   
                    select[count].append((i,j))
        return select
    # 里面有Q的所有米字形 放True
    def check1(self,dp,n,back_pop):
        take=[[False for i in range(n)] for j in range(n)]
        for l in back_pop:
            i,j=l 
            take = self.check(take,n,i,j)
        return take
    
    def check(self,take,n,i,j):
        for k in range(n):
            take[i][k]=True
            take[k][j]=True
        #y=kx+b
        up_i,up_j=i,j
        while (up_i !=0 and up_j !=n-1):
            up_i -=1
            up_j +=1
            take[up_i][up_j] =True
            
        down_i,down_j=i,j
        while (down_i != n-1 and down_j !=0):
            down_i +=1
            down_j -=1
            take[down_i][down_j] =True  
        #y=-kx+b
        up_i,up_j=i,j
        while (up_i !=0 and up_j !=0):
            up_i -=1
            up_j -=1
            take[up_i][up_j] =True
            
        down_i,down_j=i,j
        while (down_i != n-1 and down_j !=n-1):
            down_i +=1
            down_j +=1
            take[down_i][down_j] =True  
        return take
import time
now=time.time()
ss=Solution()
n=9
s=ss.solveNQueens(n)
end=time.time()
print(end-now)