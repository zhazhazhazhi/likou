# -*- coding: utf-8 -*-
"""
Created on Wed Jul 24 19:19:08 2019

@author: zhazhi


nums =  [-1, 0, 1, 2, -1, -4]
nums.sort()
print(nums)
length = len(nums)
dp=[]
for i in range(length):
    for j in range(i+1,length):
        for k in range(j+1,length):
            if nums[i]+nums[j]+nums[k] ==0: 
                if [nums[i],nums[j],nums[k] ] not in dp:
                    dp.append( [ nums[i],nums[j],nums[k]]  )
print(dp)
"""
