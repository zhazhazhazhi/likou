# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 16:09:24 2019

@author: zhazhi
"""

class Solution:
    def strStr(self, haystack: str, needle: str) -> int:
        if not needle:
            return 0
        length=len(haystack)
        length2=len(needle)
        head=0
        end=length2
        
        for i in range(length):
            count=0
            if haystack[i]== needle[head]:
                for j in range(length2):
                    if i+length2 > length:
                        break
                    
                    if haystack[i+j]== needle[head+j] and  haystack[i+length2-1-j] ==  needle[end-1-j]:
                        count+=1
                        if count==length2:
                            return i
                    else:
                        break
            else:
                continue
        return -1
            
            
            
            
        
        
        
        
        
s=Solution()
haystack="mississippi"
needle="sippia"


#"mississippi"
#"issipi"

a=s.strStr(haystack,needle)
print(a)