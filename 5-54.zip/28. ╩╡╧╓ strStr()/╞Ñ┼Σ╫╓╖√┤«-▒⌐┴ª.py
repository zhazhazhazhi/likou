# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 14:29:53 2019

@author: zhazhi
"""

class Solution:
    def strStr(self, haystack: str, needle: str) -> int:
        if not needle:
            return 0
        length=len(haystack)
        length2=len(needle)
        if length <length2:
            return -1
        index=0
        for i in range(length):
            if haystack[i]==needle[index]  :
                k=0
                while (index < length2  and i+k <= length-1):
                    if haystack[i+k]==needle[index]:
                        if index+1==length2:
                               return i
                    else:
                        index=0
                        break
                    index+=1
                    k+=1
            else:
                continue
        return -1
s=Solution()
haystack="aaa"
needle="a"
a=s.strStr(haystack,needle)
print(a)

