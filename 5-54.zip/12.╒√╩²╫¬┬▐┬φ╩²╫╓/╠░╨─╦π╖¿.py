# -*- coding: utf-8 -*-
"""
Created on Sat Jul 20 21:52:20 2019

@author: zhazhi
"""
#总是做出在当前看来是最好的选择  ，尽量使用靠前的数字 和找钱一样
x=1994
nums = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
romans = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
res=''
index=0
while(index < 13 ):
    while(nums[index]<= x):
        res += romans[index]
        x = x - nums[index]
    index +=1    
            
         
     
print(res)
        
            
           

    
    

