# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 23:14:20 2019

@author: zhazhi
"""

x=38
y=['I','V','X','L','C','D','M']
value=[]
yushu=0
count=0
while(x):
    yushu =  x % 10
    x =int(x/10)
    count +=1
    if count ==1:
        if yushu<4:
            value.append( y[0]*yushu )
        if yushu ==4:
            value.append(y[0]+y[1])
        if yushu==9:
            value.append(y[0]+y[2])
        if yushu>4 and yushu<9:
            value.append(y[1]+y[0]*(yushu-5))
    if count ==2:
        if yushu <4:
            value.append(y[2]*yushu)
        if yushu == 4:
            value.append(y[2]+y[3])
        if yushu==9:
            value.append(y[2]+y[4])
        if yushu>4 and yushu<9:
            value.append(y[3]+y[2]*(yushu-5))
    if count ==3:
        if yushu <4:
            value.append(y[4]*yushu)
        if yushu == 4:
            value.append(y[4]+y[5])
        if yushu==9:
            value.append(y[4]+y[6])
        if yushu>4 and yushu<9:
            value.append(y[5]+y[4]*(yushu-5))    
    if count ==4:
        if yushu <4:
            value.append(y[6]*yushu)
value.reverse()
value=''.join(value)
print(   value          )
