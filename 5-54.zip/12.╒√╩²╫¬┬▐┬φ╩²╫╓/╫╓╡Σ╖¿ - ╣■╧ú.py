# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 23:08:41 2019

@author: zhazhi
"""

x=38
Hash={1000: 'M',900: 'CM',500: 'D',400: 'CD',100: 'C',  90: 'XC', 
       50: 'L', 40: 'XL', 10: 'X',  9: 'IX',  5: 'V', 4: 'IV',1: 'I',}
value=[]
if x in Hash:
    print(Hash[x])
else:
    for key in Hash.keys():
        a=x//key
        if a ==0:
            continue
        if x >= key:
            value.append(Hash[key] *a )
        x=x - key*a

            
value=''.join(value)
print(value)            
            
