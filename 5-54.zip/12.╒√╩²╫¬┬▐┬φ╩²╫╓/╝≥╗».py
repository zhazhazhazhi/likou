# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 23:14:20 2019

@author: zhazhi
"""

x=8
y=['I','V','X','L','C','D','M']
x=list( str(x) )
x.reverse()
length =len(x)
value=[]
for i in range(length):
    x[i] = int(x[i])
    if x[i]<4:
        value.append( y[2*(i+1)-2]*x[i] )
    if x[i] ==4:
        value.append(y[2*(i+1)-2]+y[2*(i+1)-1])
    if x[i]==9:
        value.append(y[2*(i+1)-2]+y[2*(i+1)])
    if x[i]>4 and x[i]<9:
        value.append(y[2*(i+1)-1]+y[2*(i+1)-2]*(x[i]-5))    
  
value.reverse()
value=''.join(value)
print(   value          )
