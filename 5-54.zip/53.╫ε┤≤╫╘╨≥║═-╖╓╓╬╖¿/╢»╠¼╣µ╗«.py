# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 20:50:31 2019

@author: ACER
"""
class Solution(object):
    def maxSubArray(self, nums):
        if len(nums)==0:
            return None
        cur_sum=0
        res=nums[0]
        n=len(nums)
        for i in range(n):
            if(cur_sum>0):
                cur_sum+=nums[i]
            else:
                cur_sum=nums[i]
            res=max(res,cur_sum)    
        print( res)
    
ss=Solution()
#nums=[-2,-1,-3,4,-1,2,1,-5,4]
nums=[-2,-1,-3,4,-5,-1,2,1,6,4]
#nums=[-2147483647]
s=ss.maxSubArray(nums)