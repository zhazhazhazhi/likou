# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 23:33:58 2019

@author: ACER
"""

class Solution(object):
    def maxSubArray(self, nums):
        if len(nums)==0:
            return None
        count =-1
        left= 1
        flag=True
        value = 0
        dp=[]
        while (count < len(nums)-1):
            count +=1
            if nums[count] <0:
                value += nums[count]
                if value < 0:
                    flag = True
                continue
            if flag:
                left =count   
            value=sum(nums[left:count+1])
            dp.append(value)
            flag = False
        if len(dp)==0:
            print(max(nums))
        else:
            print(max(dp))

ss=Solution()
#nums=[-2,-1,-3,4,-1,2,1,-5,4]
nums=[-2,-1,-3,4,-5,-1,2,1,6,4]
#nums=[-2147483647]
s=ss.maxSubArray(nums)