# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 22:34:56 2019

@author: ACER
"""

class Solution(object):
    def myPow(self, x: float, n: int) -> float:
        
        if n ==0:
            return 1
        if n==-1:
            return 1/x
        result  = self.myPow(x,n//2)
        # 偶数平方 (result 的平方不是x的平方)
        if n%2==0:
            result=result**2
            return result
        else:
#            奇数直接在result 的基础上乘以一个x
            result=result*result*x
            return result
            

        
            
ss=Solution()
x=2

y=2147483647

x=2.00000

y=-2
s=ss.myPow(x,y)
#print()
print(s)
