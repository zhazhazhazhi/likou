# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 20:50:08 2019

@author: ACER
"""

class Solution(object):
    def myPow(self, x: float, n: int) -> float:
        if n==0 :
            return 1.00000
        if x==1 or x==0 or n==1:
            return x
        if x==-1:
            if abs(n)%2==0:
                return 1
            else:
                return -1
        length = abs(n)
        Positive_limit= 2**1024
        negtive_limit = 0.1**6
        sign =False
        if x <0:sign = True
        x= abs(x)
        if x >0 and x<1:
            if n > 0:  
                result = x
                for i in range(length-1):
                    result = result *x
                    if result <=negtive_limit:
                        return 0
            else:
                x=1/x
                result=x
                for i in range(length-1):
                    result = result*x    
                    if result > Positive_limit:
                        break
        else:  
            if x >1:                
                if n > 0:
                    result = x
                    for i in range(length-1):
                        result = result *x
                        if result > Positive_limit:
                            break
                else:
                    x=1/x
                    result=x
                    for i in range(length-1):
                        result = result *x
                        if result <=negtive_limit:
                            return 0 
        if sign:
            if n%2==1:
                result=-1*result
        return result
            
ss=Solution()
x=2

y=2147483647

x=-13.62608

y=4
s=ss.myPow(x,y)
print(s)
