# -*- coding: utf-8 -*-
"""
Created on Sun Sep 29 21:52:51 2019

@author: ACER
"""

class Solution:
    def isMatch(self, s: str, p: str) -> bool:
        i,j=0,0
        start=-1
        match=0
        while (i < len(s)):
            
            # 匹配s 与p 中相同的字符
            if j < len(p) and (s[i]==p[j] or p[j]=="?"):
                i+=1
                j+=1
            
            # 当p[j] 为 * 的时候，记录p的"*"的位置,还有s的位置，并且 j 向前移动 
            elif j < len(p) and p[j]=="*":
                start=j   # * 的位置
                j+=1  # j向前
                match=i  #  s   的位置
            
             # j 回到 记录的下一个位置
             # match 更新下一个位置
             #不断扩展i,直到遇到一个s[i]==('*'号后面的字符)，然后再继续匹配
            elif start != -1:   
                j = start +1
                match +=1    # 将s中匹配的位置不断的向前移动， 
                i = match
            else:
                return False
               # i = i +1
        #s匹配完成，p可能还没有遍历完，进一步处理
        
        for x in p[j:]:
            if x != "*":
                return False
        print(True)
                
                
ss=Solution()
#s = "adceb"
#p = "*a*b"
s= "aa"
p= "*a"
#s = "abcdef"
#p = "ab*f"
s=ss.isMatch(s,p)
print(s)