# -*- coding: utf-8 -*-
"""
Created on Sat Sep 28 21:53:02 2019

@author: ACER
"""

class Solution:
    def isMatch(self, s: str, p: str) -> bool:
        dp=[[False for i in range(len(s)+1)]for j in range (len(p)+1)]
        dp[0][0]=True
        for i in range(1,len(p)+1):
            if p[i-1]=="*":
                dp[i][0] = dp[i-1][0]
        for i in range (len(p)):
            for j in range (len(s)):
                if p[i]==s[j] or  p[i]=="?":
                    dp[i+1][j+1]=dp[i][j]
                elif p[i]=="*":
                    dp[i+1][j+1]=dp[i][j] or dp[i+1][j] or dp[i][j+1]
                else:
                    continue
        for k in dp:
            print(k)    
        print(dp[-1][-1])
ss=Solution()
#s = "adceb"
#p = "*a*b"
s= "adaeb"
p= "*a*b"
#s = "abcdef"
#p = "ab*f"
s=ss.isMatch(s,p)
