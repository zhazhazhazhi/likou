# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 14:54:16 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None
        
def creatlist(nums):
    last=None
    for num in reversed (nums):
        node=ListNode(num)
        node.next=last
        last=node
    return last

class Solution:
    def swapPairs(self, head: ListNode) -> ListNode:
        if head==None:
            return None
        if head.next==None:
            return head
        else:
            start=head
            end=head.next
            head=head.next.next
            end.next=start
            start.next=self.swapPairs(head)
            return end
       # self.print_list(end)

    def print_list(self,node):
        while(node):
            print(node.val,' ',end ='')
            node=node.next


if __name__ =="__main__":
    l11=[1,2,3,4]
    l1=creatlist(l11)
    s=Solution()
    
    a=s.swapPairs(l1)
    s.print_list(a)