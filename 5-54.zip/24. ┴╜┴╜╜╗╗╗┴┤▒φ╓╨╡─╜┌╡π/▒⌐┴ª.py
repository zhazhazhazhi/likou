# -*- coding: utf-8 -*-
"""
Created on Wed Aug  7 12:07:50 2019

@author: zhazhi
"""

class ListNode(object):
    def __init__(self,x):
        self.val=x
        self.next=None

def creatlist(nums):
    last=None
    for num in reversed(nums):
        node=ListNode(num)
        node.next=last
        last=node
    return last

class Solution:
    def swapPairs(self, head: ListNode) -> ListNode:
        length=head
        count=0
        while(length):
            count+=1
            length=length.next
        re=ListNode(0)
        r=re
        while(1):
            start=head
            end = head.next
            head=head.next.next
            r.next=end
            r=r.next
            r.next=start
            r=r.next
            start.next=None
            count-=2
            
            if count==1:
                r.next=head
                break
            if count==0:
                break
                     
  #      return re.next
        self.printlist(re.next)
    
    def printlist(self,node):
        while(node):
            print(node.val,' ',end=' ')
            node=node.next


if __name__ == '__main__':
    l11=[1,2,3,4]
    l1=creatlist(l11)
    s=Solution()
    a=s.swapPairs(l1)
    