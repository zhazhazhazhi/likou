# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 16:23:15 2019

@author: zhazhi
"""
# 104ms
x=-1001
x=str( int (x) )

if x[0] =='-':
    print(False)
else:
    length = len(x)
    new_str=['#']*(2*length+2) 
    new_str[2*length+1]='\0'
    for i in range(length):
        new_str[2*i+1]=x[i]

    for i in range(length):
        if new_str[length-i]==new_str[length+i]:
            if i==length-1:
                print(True)
                break
        else:
            print(False)
            break
    