# -*- coding: utf-8 -*-
"""
Created on Sun Jul 14 12:20:22 2019

@author: zhazhi
"""
#100ms
x=0
x=str(int(x ) )
if str(x)[::] == str(x)[::-1]:
    print (True)
else:
    print (False)