# -*- coding: utf-8 -*-
"""
Created on Sun Jul 14 21:09:33 2019

@author: zhazhi
"""

x=10
if (x < 0 or  (x % 10 == 0 and  x != 0)):  #  10的倍数都不是回文数字
    print(False)
else:
    revertedNumber =0
    while(x>revertedNumber ):  # 当X 小于反转数字，运行到一半
        revertedNumber = revertedNumber *10+x%10  #  一位一位的取下X的后面值，然后给 反转数字
        x=int (x/10)     #   不断更新取下X后面值的X
    if x==revertedNumber or x == int( revertedNumber/10 ):  #x == int( revertedNumber/10 )  是一位数的情况。x==revertedNumber 是多位数
        print(True)
    else:
        print(False)