# -*- coding: utf-8 -*-
"""
Created on Sun Aug  4 19:39:57 2019

@author: zhazhi
"""

def creat( s,left,right):
    if len(s) == 2 * n:
        ans.append(s)
        return ans
    if left<n :
        creat(s+'(',left+1,right)
    if right<left:
        
        creat(s+')',left,right+1)
    
    return ans
    

n=1

ans=[]
left,right=0,0
s=''
print(creat(s,left,right))
