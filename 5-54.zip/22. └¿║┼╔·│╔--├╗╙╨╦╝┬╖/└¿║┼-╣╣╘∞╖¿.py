# -*- coding: utf-8 -*-
"""
Created on Sun Aug  4 10:30:19 2019

@author: zhazhi
"""

n=6
pre = set({'()',})

    
for i in range(n-1):
    now = set()
    for st in pre:   #  插入括号()
        n = len(st)
        for index in range(n):
            now.add(st[0:index]+'()'+st[index:n])
    pre = now

print(list(pre))

