# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 22:06:18 2019

@author: zhazhi
"""

s="PAYPALISHIRING"  # 14
numRows=3

if numRows == 1:
    print(s)

rows = ['']* min(numRows, len(s))
godown = False
currow = 0
for c in s:
    rows[currow] += c
    if currow == 0 or currow == numRows-1:
        godown = not godown
    if godown:
        currow += 1
    else:
        currow -= 1
print( ''.join(rows) )
