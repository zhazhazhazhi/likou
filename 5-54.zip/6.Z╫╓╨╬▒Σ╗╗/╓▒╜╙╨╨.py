# -*- coding: utf-8 -*-
"""
Created on Wed May 15 10:33:47 2019

@author: personer
"""
a='PAYPALISHIRING'
numRows=4
s=list(a)
length=len(s)

count,k =0,0

row=0
index=0
result = ""
for i in range(4):
    for j in range(i,length,6):
        result += s[j]
     #   print(j)
        if i != 0 and i != numRows-1 and j - 2*i + 6 < length:
            result += s[j-2*i+6] 
        
print(result)   

