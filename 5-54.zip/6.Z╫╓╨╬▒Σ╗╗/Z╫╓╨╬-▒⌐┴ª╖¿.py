# -*- coding: utf-8 -*-
"""
Created on Mon Jun 17 21:11:11 2019

@author: zhazhi
 
"""
#a="PAYPALISHIRING"  # 14
s='PAYPALISHIRING'
numRows=3
length=len(s)
a=[]
currow=[0]*length
count,n=0,0
zheng_flag,ni_flag=True,False
if length==0 or numRows==1:
    print( s)
else:
    while(1):
        while (zheng_flag):
            currow[n]=count
            n,count = n+1,count+1
            if n==length: break
            if count==numRows-1: zheng_flag,ni_flag=False,True
        while (ni_flag):
            currow[n]=count
            n,count = n+1,count-1  
            if n==length:break
            if count==0: zheng_flag,ni_flag=True,False  
        if n==length: break
        
    for i in range(numRows):
        n=-1
        for c in currow:
            n+=1
            if c==i:
                a.append( s[n])
    s=''.join(a)
    print( s )
            
"""


s="PAYPALISHIRING"  # 14
numRows=3

if numRows == 1:
    print(s)

rows = ['']* min(numRows, len(s))
godown = False
currow = 0
for c in s:
    rows[currow] += c
    if currow == 0 or currow == numRows-1:
        godown = not godown
    if godown:
        currow += 1
    else:
        currow -= 1
print( ''.join(rows) )



"""







