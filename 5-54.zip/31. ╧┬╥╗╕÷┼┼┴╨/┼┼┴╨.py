# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 16:58:09 2019

@author: zhazhi
"""
#  有返回
class Solution(object):
    def nextPermutation(self, nums):
        if not nums:
            return []
        
        end=len(nums)-1
        start=end -1
        
        if nums[start] <nums[end]:
            nums=self.compute(nums,start,end)
            return nums
        min_value=100
        j=0
        change_index=0
        for  i in range ( len(nums)-1,-1,-1 ):
            if nums[i-1] >=nums[i]:
                continue
            else:
                change_index=i-1
                break
        

        for i in range (change_index +1 ,len(nums)):
            t_value = nums[i]-nums[change_index]
    #        print(t_value)
            if t_value >0:
                if t_value < min_value:
                    min_value =t_value
                    j=i     
        
        if j==0:
            nums.sort()  
            return nums  
        nums=self.compute(nums,change_index,j)        
        
        change_index =change_index +1
        start=change_index 
        end=start+1

        while (end < len(nums)):
            if nums[start] > nums[end]:
                nums=self.compute(nums,start,end)
                start=change_index
                end=start+1       
            else:
                start=end
                end=end+1
            print(nums)
                
    def compute (self,nums,start_,end_): 
        temp=nums[start_]
        nums[start_]=nums[end_]
        nums[end_]=temp
        return nums

ss=Solution()
nums=[2,2,7,5,4,3,2,2,1]
a=ss.nextPermutation(nums)
print(a)

