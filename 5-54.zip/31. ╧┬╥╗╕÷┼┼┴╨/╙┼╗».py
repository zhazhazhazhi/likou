# -*- coding: utf-8 -*-
"""
Created on Thu Aug 22 21:13:39 2019

@author: zhazhi
"""

class Solution(object):
    def nextPermutation(self, nums):
        
        length= len(nums)-1
        i=length-1
        while (i >=0) and nums[i+1]<=nums[i]: #从右边开始比较，看前面的是否大于后面，并记录需要交换的i 
            i-=1
        
        if i >=0:
            j=length
            while ( j>= 0 ) and nums[j]<=nums[i] :  # 找到比i这个位置大的数，因为右边是排序的。 要与i交换的位置
                j-=1
            self.compute(nums,i,j)

        self.reverse(nums,i+1)
        print(nums)
    def reverse(self,nums,start):
        i=start
        j=len(nums)-1
        while (i<j ):
            self.compute(nums,i,j)
            i+=1
            j-=1
       
    def compute (self,nums,start_,end_): 
        temp=nums[start_]
        nums[start_]=nums[end_]
        nums[end_]=temp


ss=Solution()
nums=[9,8,7,6,5,4,3,2,1]
a=ss.nextPermutation(nums)
print(a)
