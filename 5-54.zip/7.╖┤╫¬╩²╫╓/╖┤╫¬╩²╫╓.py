# -*- coding: utf-8 -*-
"""
Created on Tue Jul  2 21:19:47 2019

@author: zhazhi
"""

x=-1534236469

if x<0:
    x=list(str(x) )
    length=len(x)    #4
    s=['-']*length
    for i in range(1,length):
        s[length-i]=x[i]
    s= int (''.join(s)  )
    if s< - (2**31 ):
        print(- 2**31 )
else:
    x=list(str(x) )
    length=len(x)   #3
    s=['']*length
    for i in range(length):
        s[length-i-1]=x[i]
    s= int(''.join(s))
    if s> (2**31 -1):
        print(2**31 -1)
 