# -*- coding: utf-8 -*-
"""
Created on Tue Jul  2 23:58:50 2019

@author: zhazhi
"""

x=123456987
if -2**31 <= x < 0:
    x = str(x)[1:]
    x = x[::-1].lstrip('0')
    if int(x) > 2**31:
        print(0) 
    else:
        print (int('-' + x) )
elif  x == 0:
    print(0) 
elif  x < 2**31:
    x = str(x)[::-1].lstrip('0')
    if int(x) >= 2**31:
        print(0) 
    else:
        print(int(x))  
else:
    print(0)
