# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 19:43:01 2019

@author: zhazhi
"""

class Solution(object):
    def solveSudoku(self, board):
        
        unwrite_k=[]
        dic={'1':0,'2':1,'3':2,'4':3,'5':4,'6':5,'7':6,'8':7,'9':8}
        
        record_index,record_value=[],[]
        index_findindex,value_fondindex=[],[]
        count2 =0
        flag=False
        self.back_tract(board,unwrite_k,dic,record_index,record_value,index_findindex,value_fondindex,count2,flag)
        for n in board:
            print(n)
     
    def back_tract(self,board,unwrite_k,dic,record_index,record_value,index_findindex,value_fondindex,count2,flag):

        every_square_count=self.isValidSudoku(board,dic)
        hang_count,lie_count =self.compute(board,dic)
        index_count,total_value,count=self.solve(board,dic,every_square_count,hang_count,lie_count)
        
        if count ==0:
            return board
        
        index, value=self.findindex(index_count)  
        index_findindex.append(index),value_fondindex.append(value)
        record_index.append(index),record_value.append(value)
        unwrite_k=self.write_value(total_value,index, value,unwrite_k)  
        if count2 >2:
            flag=self.find_mistake(record_index, record_value)
        if flag:
            while (1):
                length =len(record_index)
                length2 =len(unwrite_k)
                if record_index[length -1] == unwrite_k[length2-1][0] and record_value[length -1] == unwrite_k[length2-1][1]:
                    board[unwrite_k[length2-1][0]][unwrite_k[length2-1][1]]=str(unwrite_k[length2-1][2])
                    count-=1
                    unwrite_k.pop()
                    break
                else:
                    board[record_index[length-1] ][record_value[length-1]]='.'
                    record_index.pop()
                    record_value.pop()
                    count +=1       
                
        count2+=1

        self.back_tract(board,unwrite_k,dic,record_index,record_value,index_findindex,value_fondindex,count2,flag)
        
   
    def find_mistake(self,index,value):
        length =len(index)-1
        if index[length] == index[length-1] and value[length] ==value[length-1]:
         #   print("出错误了 ")
            return True

    def write_value(self,total_value,index, value,unwrite_k):
        dic1={1:"1",2:"2",3:"3",4:"4",5:"5",6:"6",7:"7",8:"8",9:"9"}
        test=0
        for k in dic1:
            if k not in total_value[index][value]:
                if test ==0:
                    board[index][value]=str(k)
                else:
                    unwrite_k.append([index,value,k])
                test +=1
        return unwrite_k
             
    def findindex(self,index_count):
        temp=0
        hang_index=0
        lie_index=0
        for i in range (9):
            j=index_count[i]
            value = max(j)
            if temp <value:
                hang_index=i
                lie_index=j.index(value)
                temp=value
        return hang_index, lie_index
        
    def solve(self,board,dic,every_square_count,hang_count,lie_count):
        lie_index=0
        row_count =0    
        liter_count=0
        index=[[0 for i in range (9)] for j in range (9)]
        last_set1=[[0 for i in range (9)] for j in range (9)]
        count=0
        while (lie_index <9):
            for i in range (lie_index,lie_index+3):
                for j in range (row_count,row_count+3):
                    left_value=board[i][j]
                    if left_value == ".":
                        hang_set= set(  hang_count[i] )
                        lie_set = set( lie_count[j]  )
                        liter_set = set(every_square_count[liter_count] )
                        last1=hang_set | lie_set | liter_set
                        count +=1
                        index[i][j]=  len(last1)
                        last_set1[i][j]=last1   
                    else:
                        continue
                if i %3== 2:
                    liter_count+=1 
            row_count +=3
            if row_count == 9:
                lie_index+=3
                row_count=0   
        return index,last_set1,count

    def compute(self,board,dic):  
        lie_index,hang_index=[],[]
        for i in range (9):
            hang,lie=[],[]
            for j in range (9):
                left_value=board[i][j]
                down_value = board[j][i]
                if left_value=="." and down_value ==".":
                    continue
                else:
                    if left_value in dic:
                        hang.append(int (left_value ))
                    if down_value in dic:
                        lie.append(int (down_value ))        
            lie_index.append(lie),hang_index.append(hang)
        return hang_index ,  lie_index  
        
    def isValidSudoku(self, board,dic):
        lie_count,row_count =0,0
        dp_index,dp=[],[]
        while (lie_count<9):
            for i in range (lie_count,lie_count+3):
                for j in range (row_count,row_count+3):
                    left_value=board[i][j]
                    if left_value=="." :
                        continue
                    else:
                        if left_value  in dic:
                            dp.append( int (left_value) )
            row_count +=3
            dp_index.append(dp)
            dp=[]
            if row_count == 9:
                lie_count+=3
                row_count=0  
        return dp_index    
import time
now=time.time()   
ss=Solution()
board=[["5","3",".", ".","7",".", ".",".","."],
       ["6",".",".", "1","9","5", ".",".","."],
       [".","9","8", ".",".",".", ".","6","."],
       
       ["8",".",".", ".","6",".", ".",".","3"],
       ["4",".",".", "8",".","3", ".",".","1"],
       ["7",".",".", ".","2",".", ".",".","6"],
       
       [".","6",".", ".",".",".", "2","8","."],
       [".",".",".", "4","1","9", ".",".","5"],
       [".",".",".", ".","8",".", ".","7","9"]]

board=[["5",".",".", ".","3","9", ".","6","."],
       [".",".",".", ".",".",".", ".","9","."],
       [".",".",".", "5",".","8", "2",".","."],
       
       ["6",".","5", "8",".",".", "3",".","."],
       [".","9",".", ".","1",".", ".","2","."],
       [".",".","8", ".",".","3", "5",".","6"],
       
       [".",".","9", "7",".","6", ".",".","."],
       [".","2",".", ".",".",".", ".",".","."],
       [".","5",".", "9","8",".", ".",".","."]]

board=[[".",".","9", "7","4","8", ".",".","."],
       ["7",".",".", ".",".",".", ".",".","."],
       [".","2",".", "1",".","9", ".",".","."],
       
       [".",".","7", ".",".",".", "2","4","."],
       [".","6","4", ".","1",".", "5","9","."],
       [".","9","8", ".",".",".", "3",".","."],
       
       [".",".",".", "8",".","3", ".","2","."],
       [".",".",".", ".",".",".", ".",".","6"],
       [".",".",".", "2","7","5", "9",".","."]]

board=[[".",".",".", "2",".",".", ".","6","3"],
       ["3",".",".", ".",".","5", "4",".","1"],
       [".",".","1", ".",".","3", "9","8","."],
       
       [".",".",".", ".",".",".", ".","9","."],
       [".",".",".", "5","3","8", ".",".","."],
       [".","3",".", ".",".",".", ".",".","."],
       
       [".","2","6", "3",".",".", "5",".","."],
       ["5",".","3", "7",".",".", ".",".","8"],
       ["4","7",".", ".",".","1", ".",".","."]]


s=ss.solveSudoku(board)
end=time.time()
print(end-now)

