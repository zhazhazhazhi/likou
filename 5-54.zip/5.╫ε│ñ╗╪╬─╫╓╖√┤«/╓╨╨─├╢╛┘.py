# -*- coding: utf-8 -*-
"""
Created on Thu May  2 23:07:22 2019

@author: Administrator
"""
"""
import time 
now=time.time()
#s='asdaadff'
#s="ebbbdefg"  #  7 
#s=''
s="abababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababa"
max_length=len(s)
youhua='0'
pre_length=0
now_length=0

if max_length==0:
    youhua=''


for i in range(max_length): #1,2,3,4,5
    for j in range(i,max_length):
        length=len(s[i:j+1])
        #print(i,j,' ',s[i:j+1],' ',length)
        if length % 2 == 0:
            length1=int(length/2)
            for k in range(0,length1):
                if s[i+k]==s[j-k]:
                    if k==length1 -1:
                        pre_length=len(youhua)
                        now_length=len(s[i:length+i])
                        if now_length > pre_length:
                            youhua=s[i:length+i] 
                                #print(youhua)
                else:break     
        if length % 2 == 1: #3,5,7
            length1=int(length/2) #2.3.4
            for k in range(0,length1):
                if s[k+i]==s[j-k]:
                    if k==length1 -1:
                        pre_length=len(youhua)
                        now_length=len(s[i:length+i])
                        if now_length > pre_length:
                            youhua=s[i:length+i] 
                else:break
end=time.time()
print(youhua)
#print(end-now)
        

"""   
        
        
import time 
now=time.time()
#s='asdaadff'
#s="ebbbbdefg"  #  7 
s='cd'
#s="abababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababa"
max_length=len(s)
youhua='0'
pre_length=0
now_length=0
is_None=1
if max_length==0:
    is_None=0
    print('nothing')
if is_None==1:
    for i in range(max_length): #1,2,3,4,5
        for j in range(i,max_length):
            length=len(s[i:j+1])
            length1=int(length/2)
            for k in range(0,length1):
                if s[i+k]==s[j-k]:
                    if k==length1 -1:
                        pre_length=len(youhua)
                        now_length=len(s[i:length+i])
                        if now_length > pre_length:
                            youhua=s[i:length+i] 
                else:break  
    
    if len(youhua)==1:
        print(s[max_length-1])
  
    else:           
        print(youhua)
        
end=time.time()
#print(youhua)
print(end-now)        
        
        
        
        

     