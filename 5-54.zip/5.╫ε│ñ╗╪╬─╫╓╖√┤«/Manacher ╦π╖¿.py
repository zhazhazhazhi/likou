# -*- coding: utf-8 -*-
"""
Created on Fri May 10 14:23:37 2019

@author: Administrator
"""

s='ababc'
ss=list(s)
length=len(ss)
new_str=['#']*(length*2+3)
new_str[0]='$'
for k in range(length):
    new_str[2*k+2]=ss[k]
new_length=len(new_str)
new_str[new_length-1]='\0'
p_h=[0]*(new_length )
max_right=0
ids=0
max_len=''
for i in range(1,new_length-1):
    # 求p_h （包括自己的回文半径）
    if i<max_right: # 以 ids 为中心 ，max_right为ids 能到的最右边 ，当i 在ids回文串里面时，
        # 2*ids-1 为i 对称点j 到ids的距离。 
        p_h[i]=min(p_h[2*ids-1],max_right-i)
        
    else:
        p_h[i]=1
        
    while (new_str[i- p_h[i] ] == new_str[i+ p_h[i]  ]   ):
        p_h[i] +=1
    #跟新ids（中心），和能到达的最右边
    if i+p_h[i] >max_right : 
        ids=i
        max_right =i+p_h[i] -1
    
    if 2*p_h[i] >max_right:
        max_len=new_str[i - p_h[i]+1 : i + p_h[i] ]
    
max_len=''.join(max_len)   # 列表转换成字符串
max_len1=max_len.replace("#",'')
print(max_len1)  
    
    
    
    
