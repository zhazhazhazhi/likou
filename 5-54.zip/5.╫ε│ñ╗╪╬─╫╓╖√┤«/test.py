# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 21:56:30 2019

@author: Administrator

"""
import time
start=time.time()
#a="abababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababa"
#print(len(a)  )
s="abababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababababa"
#s="cbbd"
#s="eabcb"
#s='cbbd'
#s='asdaadff'
length=len(s)
max1=[]
is_None=1

pre_length=0
now_length=0
youhua='0'

if length==0:
    is_None=0
    print('nothing')
    
if is_None==1:
    for i in range(length):
        for j in range(i+1,length):
            index=(j+i) 
            meadin=int(index/2) +1
            for k in range(i,meadin):
                if s[k] != s[j-k+i]:
                    break                        
                if s[k] == s[j-k+i]:
                    if k==meadin-1:
                        pre_length=len(youhua)
                        now_length=len(s[i:j+1])
                        if now_length>pre_length :
                            youhua=s[i:j+1]        
                
    if len(youhua)==1:
        print(s[length-1])
  
    else:           
        print(youhua)
    
end=time.time()
print('时间'+str(end-start))              





