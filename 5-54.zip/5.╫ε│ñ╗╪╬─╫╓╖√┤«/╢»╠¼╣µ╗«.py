# -*- coding: utf-8 -*-
"""
Created on Wed May 22 20:36:01 2019

@author: Administrator
"""
"""
动态规划法，是从底向上，从最基础的子问题到复杂
写出初状态和
状态转移方程

"""
s="abbbc"
length=len(s)
#matrix = [[0 for i in range(length)] for i in range(length)] # 初始化n*n的列表 
k=0
dp=[]
max_str='0'
str1='0'
for k in range(length):
    dp.append([])
    for kk in range(length):
        dp[k].append(0)

for i in range(length):
    for j in range(0,i+1):
        if i-j<=1:
            if s[i]==s[j]:
                dp[i][j]=1
                str1=s[j:i+1]
                if len(max_str)<=len(str1):
                    max_str=str1  
        else:
            if s[i]==s[j]:
                if dp[i-1][j+1]:
                    dp[i][j]=1
                    str1=s[j:i+1]
                   # print(j,i)
                    if  len(max_str) <=len(str1):
                        max_str=str1                    
print(max_str)       

        
            







