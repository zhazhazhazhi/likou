# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 22:19:47 2019

@author: zhazhi
"""

nums = [1,2,4,8,16,32,64,128]

#nums=[1,2,3,4]
nums.sort()
target = 82
dp=[]
dic={}
search={}
value=0

if len(nums)<3:
    print('kong')
else:
    for i  in range(len(nums)):
        left=i+1
        right=len(nums)-1
        while(left<right):
            sum1=nums[i]+nums[left]+nums[right]
      #      dp.append ([nums[i],nums[left],nums[right]])
            if (sum1*target) >=0 :
                value=abs(sum1-target)
            if (sum1*target) <0 :
                value =abs(sum1)+abs(target)

            dic[value]=sum1
            if sum1-target<0:
                left+=1
            else:# sum1>=0:
                right-=1      
    min_value=(min(dic.keys()) )
    value = dic[min_value]

   