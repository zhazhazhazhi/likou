# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 22:19:47 2019

@author: zhazhi
"""

nums = [1,1,-1,-1,3]
# 128秒
nums = [1,2,4,8,16,32,64,128]
#nums=[-1,2,1,-4]
nums.sort()
target = 82
value=0
min_value =10000000
ans=0
if len(nums)<3:
    print('kong')
else:
    for i in range(len(nums) ):
        if i>0 and nums[i] == nums[i-1]:
            continue
        left=i+1
        right=len(nums)-1
        while(left<right):
            sum1=nums[i]+nums[left]+nums[right] 
            
            value =abs( target -sum1 )
            if value==0:
                print(sum1)
                break
            if value <min_value:
                min_value =value
                ans=sum1
            if sum1>target :
                right-=1
            else:
                left+=1
            
            
 #   print(ans)


   